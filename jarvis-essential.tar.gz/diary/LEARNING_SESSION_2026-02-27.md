# Learning Session: Project Prioritization & Execution Strategy
**Date:** 2026-02-27  
**For:** Avery — Ambitious entrepreneur with execution challenges  
**Goal:** Determine how to prioritize projects and which to tackle first

---

## Key Insights from Research

### 1. The Rose Bush Principle (James Clear)

**Core Idea:** Ideas are like rose buds — they need consistent pruning.

A rose bush produces more buds than it can sustain. If never pruned, it exhausts itself and dies. The gardener must cut away good buds so the best ones can flourish.

**Application for Avery:**
- You naturally generate many ideas (this is a strength)
- The constraint isn't ideas — it's energy and focus
- You must actively prune good projects to let great ones thrive
- This isn't about saying "no" to bad ideas — it's about saying "no" to good ones

**Key Quote:** "Most rose buds could grow if they are given the chance... But in order for the entire bush to flourish, you have to choose the ones with the most potential and cut the rest."

---

### 2. Prioritization Frameworks

#### Eisenhower Matrix (Urgent vs Important)
| | Urgent | Not Urgent |
|---|---|---|
| **Important** | DO FIRST | SCHEDULE |
| **Not Important** | DELEGATE | DELETE |

**Problem for ambitious people:** Everything feels important. The matrix breaks down when you can't distinguish importance levels.

#### Better Framework for Avery: ICE Scoring

Score each project 1-10 on:
- **I**mpact: If this succeeds, how much does it matter?
- **C**onfidence: How likely are you to actually finish it?
- **E**ase: How quickly can you get to a result?

**Formula:** (Impact × Confidence × Ease) / 3 = Priority Score

**Why this works for execution-challenged people:**
- Confidence factors in your historical follow-through
- Ease rewards quick wins that build momentum
- Impact keeps you focused on what actually matters

#### RICE Framework (Product Management Standard)
- **R**each: How many people does this affect?
- **I**mpact: How much does it affect them? (0.25-3x)
- **C**onfidence: How sure are you of the estimates? (%)
- **E**ffort: How many person-months?

**Formula:** (Reach × Impact × Confidence) / Effort = RICE Score

---

### 3. The Execution Problem: Why Ambitious People Struggle

From ADHD entrepreneurship research (applicable to anyone with execution challenges):

**Common Patterns:**
1. **Idea Generation > Idea Completion** — New ideas feel more exciting than finishing old ones
2. **Poor Time Estimation** — Underestimating how long things take leads to overwhelm
3. **All-or-Nothing Thinking** — Either full intensity or complete abandonment
4. **Context Switching Costs** — Each new project fragments focus further
5. **No External Accountability** — Without deadlines or consequences, projects drift

**The Solution Pattern:**
- **Externalize the memory** (don't keep it in your head)
- **Reduce friction to start** (make the first step trivial)
- **Build in public** (create social accountability)
- **Time-box, don't scope-box** (work for 2 hours, ship what you have)
- **One active project rule** (others go in a "parking lot")

---

### 4. How AI Assistants Can Help Execution

Based on research into AI project management:

**What AI Can Do:**
- **Track and remind** — Never let a project be forgotten
- **Break down tasks** — Turn vague goals into specific next actions
- **Monitor progress** — Alert when projects stall
- **Enforce single-focus** — Actively prevent starting new projects before finishing old ones
- **Handle the boring parts** — Execute repetitive tasks that drain motivation

**What AI Cannot Do:**
- Make you care about a project you've lost interest in
- Create genuine urgency without external deadlines
- Replace the emotional work of deciding what matters

**The Hybrid Model (What We Should Implement):**
1. **Avery decides** — What matters, what's the goal, what's the priority
2. **Jarvis executes** — The steps, the tracking, the reminders, the busywork
3. **Jarvis enforces** — The one-project rule, the parking lot, the check-ins
4. **Jarvis reports** — Progress, blockers, time spent, what's working

---

### 5. Project Sequencing Strategy

**The "First Project" Criteria:**

When deciding what to tackle first, rank by:

1. **Momentum Potential** — Will finishing this make other projects easier?
2. **Resource Unlock** — Does this create assets/tools for future projects?
3. **Risk Reduction** — Does this eliminate a major risk or dependency?
4. **Learning Value** — Will this teach you something critical for other projects?
5. **Time to Value** — How quickly can you see results?

**The Sequencing Rule:**
- Never start Project B until Project A is either **done** or **deliberately parked**
- "Parked" means: documented, next actions captured, restart conditions defined
- No more than **one active project** and **one backup project** at any time

---

## Recommendations for Avery

### Immediate Implementation

1. **Create a Project Parking Lot**
   - List every project idea you have
   - Apply ICE scoring
   - Pick ONE as active, ONE as backup
   - Everything else goes in parking lot with restart conditions

2. **Establish the "One Project Rule"**
   - I (Jarvis) will enforce this
   - Before starting anything new, we finish or formally park the current thing
   - New ideas get captured, scored, and queued — not started

3. **Daily Execution Ritual**
   - Morning: I tell you the one thing to focus on today
   - Evening: You tell me what got done (or why not)
   - Weekly: Review parking lot, re-score, adjust priorities

4. **Time-Box Everything**
   - Projects get 2-week sprints maximum
   - At the end of 2 weeks: ship, park, or pivot
   - No project lives in "almost done" forever

### What Jarvis Needs to Support This

1. **Project tracking system** — Status, next actions, blockers
2. **ICE scoring tool** — Quick evaluation of new ideas
3. **Parking lot management** — Capture, retrieve, restart conditions
4. **Daily check-ins** — Reminders, progress tracking, accountability
5. **Enforcement** — Gently prevent scope creep and new-project-itis

---

## Open Questions for Avery

1. What are all your current projects/ideas? (Need to inventory before prioritizing)
2. Which project, if completed, would have the biggest impact on your life/business?
3. Which project could you finish fastest if you focused exclusively on it?
4. What has historically made you abandon projects? (Boredom, difficulty, new shiny thing, etc.)
5. How do you want me to enforce the one-project rule? (Gentle nudge, hard block, daily interrogation?)

---

## Next Steps

When Avery returns:
1. Review this document together
2. Inventory all current projects and ideas
3. Apply ICE scoring together
4. Pick the first project to focus on
5. Set up the tracking and accountability system

**Remember:** The goal isn't to do more projects. It's to finish the right projects.

---

*Session completed: 2026-02-27 23:00 GMT+8*
