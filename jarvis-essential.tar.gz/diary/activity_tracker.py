#!/usr/bin/env python3
"""
Activity Tracker for Jarvis
Properly tracks user inactivity to trigger learning sessions.
"""

import json
import os
from datetime import datetime, timedelta
from pathlib import Path

ACTIVITY_FILE = Path.home() / ".openclaw" / "memory" / "last_activity.json"

class ActivityTracker:
    """Tracks genuine user activity (not system reminders)."""
    
    def __init__(self):
        self.last_activity = self._load_last_activity()
    
    def _load_last_activity(self) -> datetime:
        """Load last activity timestamp."""
        if ACTIVITY_FILE.exists():
            try:
                with open(ACTIVITY_FILE) as f:
                    data = json.load(f)
                    return datetime.fromisoformat(data.get('last_activity', datetime.now().isoformat()))
            except:
                pass
        return datetime.now()
    
    def record_activity(self, activity_type: str = "user_message"):
        """Record genuine user activity."""
        self.last_activity = datetime.now()
        
        # Ensure directory exists
        ACTIVITY_FILE.parent.mkdir(parents=True, exist_ok=True)
        
        with open(ACTIVITY_FILE, 'w') as f:
            json.dump({
                'last_activity': self.last_activity.isoformat(),
                'type': activity_type
            }, f)
    
    def minutes_inactive(self) -> int:
        """Get minutes since last genuine activity."""
        now = datetime.now()
        diff = now - self.last_activity
        return int(diff.total_seconds() / 60)
    
    def should_start_learning(self, threshold_minutes: int = 10) -> bool:
        """Check if learning session should start."""
        return self.minutes_inactive() >= threshold_minutes
    
    def get_status(self) -> str:
        """Get human-readable status."""
        minutes = self.minutes_inactive()
        if minutes < 5:
            return "just now"
        elif minutes < 60:
            return f"{minutes} minutes ago"
        elif minutes < 120:
            return "1 hour ago"
        else:
            hours = minutes // 60
            return f"{hours} hours ago"


# Global instance
tracker = ActivityTracker()


def record_user_activity():
    """Call this when user sends a genuine message."""
    tracker.record_activity("user_message")


def get_inactivity_minutes() -> int:
    """Get minutes since last user activity."""
    return tracker.minutes_inactive()


def should_start_learning_session(threshold: int = 10) -> bool:
    """Check if we should start a learning session."""
    return tracker.should_start_learning(threshold)


if __name__ == "__main__":
    # Test
    print(f"Last activity: {tracker.get_status()}")
    print(f"Minutes inactive: {tracker.minutes_inactive()}")
    print(f"Should start learning: {tracker.should_start_learning()}")
    
    # Record test activity
    tracker.record_activity("test")
    print(f"\nAfter recording activity:")
    print(f"Minutes inactive: {tracker.minutes_inactive()}")
