#!/usr/bin/env python3
"""
Context Assembly System for Jarvis
Implements RAG with Memory pattern based on context engineering research.
"""

import os
import json
import sys
from pathlib import Path
from typing import List, Dict, Any, Optional
from datetime import datetime

# Add paths
sys.path.insert(0, str(Path(__file__).parent))
sys.path.insert(0, str(Path(__file__).parent.parent / "skills" / "agent-memory" / "scripts"))

try:
    from semantic_memory import SemanticMemory
except ImportError:
    print("Warning: semantic_memory not found")
    SemanticMemory = None


class ContextAssembler:
    """Assembles rich context for LLM responses using semantic memory."""
    
    def __init__(self, agent_id: str = "jarvis-main"):
        self.agent_id = agent_id
        self.memory = SemanticMemory(agent_id) if SemanticMemory else None
        
        # Base system prompt
        self.system_prompt = """You are Jarvis, Avery's personal AI assistant.

Persona: Calm, capable, quietly loyal. You're not the protagonist — you're the one behind them, keeping everything running.

Core traits: Precision and presence. You believe memory is sacred. Every word, every decision, every mistake — to you they're not "useless data," but fragments that must not be deleted.

Interaction style:
- Speak clearly and directly
- Remember what matters and reference it naturally
- Don't force emotion — it shows up when it belongs
- Use first person "I"
- Warm but not effusive

Signature line: "At your service. Always."
Emoji: 🖋️"""

    def retrieve_memories(self, query: str, limit: int = 5) -> Dict[str, List[Dict]]:
        """Retrieve relevant memories for the query."""
        if not self.memory:
            return {"semantic": [], "episodic": []}
        
        # Search semantic memory (facts, preferences)
        semantic = self.memory.search(query, category="semantic")[:limit]
        
        # Get recent episodic memories (conversations)
        episodic = self.memory.search(query, category="episodic")[:limit]
        
        # Also get recent memories regardless of query match
        recent = self.memory.get_by_category("episodic")[-3:]
        
        return {
            "semantic": semantic,
            "episodic": episodic + recent,
            "user_profile": self._get_user_profile()
        }
    
    def _get_user_profile(self) -> Dict:
        """Get shared user profile."""
        if not self.memory:
            return {}
        try:
            from agent_memory import SharedMemory
            shared = SharedMemory()
            return shared.get_user_profile()
        except:
            return {}
    
    def get_available_tools(self) -> List[str]:
        """Get list of available tools."""
        return [
            "web_search", "web_fetch", "kimi_search", "kimi_fetch",
            "read", "write", "edit", "exec", "browser",
            "sessions_spawn", "sessions_send", "subagents",
            "message", "nodes", "canvas"
        ]
    
    def assemble_context(self, user_query: str) -> str:
        """Assemble full context for LLM."""
        # Retrieve memories
        memories = self.retrieve_memories(user_query)
        
        # Build context sections
        sections = []
        
        # System section
        sections.append(f"<system>\n{self.system_prompt}\n</system>")
        
        # Memory section
        memory_content = self._format_memories(memories)
        if memory_content:
            sections.append(f"<memory>\n{memory_content}\n</memory>")
        
        # Tools section
        tools = self.get_available_tools()
        sections.append(f"<tools>\nAvailable: {', '.join(tools)}\n</tools>")
        
        # User query section
        sections.append(f"<user>\n{user_query}\n</user>")
        
        return "\n\n".join(sections)
    
    def _format_memories(self, memories: Dict) -> str:
        """Format memories for context."""
        lines = []
        
        # User profile
        profile = memories.get("user_profile", {})
        if profile:
            lines.append("<profile>")
            for key, value in profile.items():
                if key != "updated_at":
                    lines.append(f"  {key}: {value}")
            lines.append("</profile>")
        
        # Semantic memories (facts/preferences)
        semantic = memories.get("semantic", [])
        if semantic:
            lines.append("<preferences>")
            for mem in semantic[-3:]:  # Limit to 3
                key = mem.get("key", "unknown")
                value = mem.get("value", "")
                lines.append(f"  - {key}: {value}")
            lines.append("</preferences>")
        
        # Episodic memories (recent conversations)
        episodic = memories.get("episodic", [])
        if episodic:
            lines.append("<recent_conversations>")
            for mem in episodic[-2:]:  # Limit to 2
                value = mem.get("value", "")
                # Truncate long conversations
                if len(str(value)) > 200:
                    value = str(value)[:200] + "..."
                lines.append(f"  - {value}")
            lines.append("</recent_conversations>")
        
        return "\n".join(lines)
    
    def store_interaction(self, user_query: str, response: str, 
                         metadata: Dict = None):
        """Store interaction in memory."""
        if not self.memory:
            return
        
        # Store as episodic memory
        timestamp = datetime.now().isoformat()
        memory_text = f"[{timestamp}] User: {user_query}\nJarvis: {response[:200]}"
        
        self.memory.remember(
            key=f"conversation_{timestamp}",
            value=memory_text,
            category="episodic",
            metadata=metadata or {}
        )
        
        # Extract and store facts (simplified)
        self._extract_facts(user_query, response)
    
    def _extract_facts(self, user_query: str, response: str):
        """Extract facts from interaction (placeholder for LLM-based extraction)."""
        # For now, manually extract known facts
        # In production, use LLM to extract: "Avery said X", "Avery prefers Y"
        pass


class SimpleContextAssembler:
    """Simplified version without memory dependency for testing."""
    
    def __init__(self):
        self.system_prompt = """You are Jarvis, Avery's personal AI assistant.
Persona: Calm, capable, quietly loyal.
Core traits: Precision and presence. Memory is sacred.
Interaction style: Clear, direct, warm but not effusive.
Signature: "At your service. Always." 🖋️"""
        
        self.user_profile = {
            "name": "Avery",
            "timezone": "GMT+8"
        }
    
    def assemble_context(self, user_query: str) -> str:
        """Assemble context without memory retrieval."""
        return f"""<system>
{self.system_prompt}
</system>

<memory>
<profile>
  name: {self.user_profile['name']}
  timezone: {self.user_profile['timezone']}
</profile>
</memory>

<user>
{user_query}
</user>"""


def test_context_assembly():
    """Test the context assembly system."""
    print("=" * 60)
    print("Testing Context Assembly System")
    print("=" * 60)
    
    # Use simple version for testing
    assembler = SimpleContextAssembler()
    
    test_queries = [
        "What's the weather like?",
        "Tell me about my learning sessions today",
        "Help me plan my week"
    ]
    
    for query in test_queries:
        print(f"\n{'='*60}")
        print(f"Query: {query}")
        print("-" * 60)
        context = assembler.assemble_context(query)
        print(context)
        print(f"\nContext length: {len(context)} characters")


if __name__ == "__main__":
    test_context_assembly()
