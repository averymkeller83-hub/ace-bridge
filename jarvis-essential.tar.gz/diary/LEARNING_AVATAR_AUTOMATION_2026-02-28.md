# Learning Session: Avatar Automation & TikTok Posting Deep Dive
**Date:** 2026-02-28 (Late Night)  
**For:** Avery's avatar-based TikTok marketing system  
**Goal:** Research API pricing and automation workflows

---

## HeyGen API for Automation

### Pricing Model (as of Feb 2026)

**Pay-as-you-go credits:**
- No free API credits (changed Feb 2026)
- Purchase credits in USD
- Credits expire after 12 months

**Credit Costs:**
- 1 credit = 1 minute of standard avatar video
- Avatar IV (premium): 1 credit per 10 seconds (~6 credits/minute)
- Video translation: 3 credits per minute of source video
- Video Agent: 2 credits per minute
- Max duration: 30 minutes per video (enterprise can extend)
- Quality: 1080p (4K requires enterprise)

**Estimated Costs for Avery's Use Case:**

Assuming 3 videos/day, 30 seconds each:
- 3 videos × 0.5 min = 1.5 minutes/day
- 45 minutes/month
- ~45 credits/month

At estimated $0.10-0.15 per credit: **$4.50-6.75/month**

Plus base HeyGen subscription ($29-89/month)
**Total: ~$35-95/month for HeyGen**

### API Capabilities

**What can be automated:**
- Video generation from templates
- Avatar selection/customization
- Script input (text-to-speech)
- Background selection
- Multi-language generation
- Bulk/batch processing

**Integration Options:**
- REST API
- Webhook callbacks
- Make.com/Zapier integration
- Python/Node SDKs

### Workflow for Avery

```python
# Pseudo-workflow
1. Get product from Etsy API
2. Generate script from product description
3. Call HeyGen API:
   - Template: "Product showcase"
   - Avatar: [Avery's custom avatar]
   - Script: [Generated from product]
   - Background: [Product image or clean]
4. Wait for webhook (video ready)
5. Download video
6. Post to TikTok via API
7. Store performance metrics
```

---

## TikTok Posting Options

### Option 1: TikTok Official Content Posting API

**Requirements:**
- TikTok Developer account
- Business account or Creator account
- App review process (can take days/weeks)
- OAuth 2.0 authentication

**Capabilities:**
- Upload videos
- Post as draft or publish directly
- Add captions, hashtags
- Schedule posts (limited)

**Limitations:**
- Strict rate limits
- Review process for apps
- Not all accounts eligible
- Complex OAuth flow

### Option 2: Unified APIs (Late, Upload-Post)

**Late.dev:**
- Single API for TikTok, Instagram, YouTube, etc.
- Simplified authentication
- Standardized endpoints
- Free tier available
- 99.97% uptime claim

**Upload-Post.com:**
- Multi-platform posting
- Python & JS SDKs
- Free tier
- 30k+ users

**Advantages:**
- One integration for all platforms
- No platform-specific OAuth headaches
- Faster development
- Easier maintenance

**Disadvantages:**
- Third-party dependency
- Potential additional cost
- Less control

### Option 3: Hybrid Approach (Recommended)

**For TikTok:** Use official API if approved, else manual upload with reminder
**For Instagram/YouTube:** Use unified API or official APIs
**For scheduling:** Cron-based with approval queue

---

## Recommended Architecture

### Phase 1: Manual with Assistance

```
Etsy Product → Script Generation → HeyGen Video → 
Notification to Avery → Manual TikTok Upload → 
Performance Tracking
```

**Why start here:**
- No TikTok API approval wait
- Avery reviews each video before posting
- Learn what works before automating
- Lower risk

### Phase 2: Semi-Automated

```
Etsy Product → Script Generation → HeyGen Video → 
Approval Queue (Avery reviews) → Auto-post to TikTok → 
Performance Tracking
```

**Requirements:**
- TikTok API approval
- Approval workflow UI
- Scheduled posting

### Phase 3: Full Automation

```
Etsy Product → Script Generation → HeyGen Video → 
Auto-post (with rules) → Performance Tracking → 
Auto-adjust based on metrics
```

**Requirements:**
- Proven content templates
- Performance data
- Safety rules (auto-pause if metrics drop)

---

## Cost Summary

| Component | Monthly Cost | Notes |
|-----------|--------------|-------|
| HeyGen Subscription | $29-89 | Creator or Pro plan |
| HeyGen API Credits | $5-20 | Depends on volume |
| TikTok API | Free | If approved |
| Unified API (Late) | $0-50 | If using instead |
| Server/VPS | $20-50 | Hosting |
| **Total** | **$54-209/month** | Starting estimate |

**Break-even:** ~20-50 product sales/month (depending on product margin)

---

## Implementation Priority

### Week 1-2: Foundation
- [ ] Set up HeyGen account
- [ ] Create custom avatar
- [ ] Build script generation
- [ ] Create 10 test videos manually

### Week 3-4: Integration
- [ ] Implement HeyGen API
- [ ] Build video generation workflow
- [ ] Create approval queue
- [ ] Test end-to-end

### Week 5-8: TikTok Integration
- [ ] Apply for TikTok API access
- [ ] OR implement unified API
- [ ] Build posting workflow
- [ ] Schedule content

### Month 3+: Optimization
- [ ] Analyze performance
- [ ] A/B test scripts
- [ ] Automate approval for trusted templates
- [ ] Scale volume

---

## Risk Mitigation

**Content Quality:**
- Always require approval before posting (initially)
- A/B test scripts
- Monitor engagement metrics
- Auto-pause if performance drops

**Platform Risk:**
- Don't rely solely on TikTok
- Cross-post to Instagram/YouTube
- Build email list (own the relationship)
- Backup content locally

**Cost Control:**
- Start with low volume
- Monitor API credit usage
- Set spending alerts
- Have manual fallback

---

## Open Questions for Avery

1. **Budget comfort:** $100-200/month for content generation reasonable?
2. **Approval workflow:** Review every video, or trust after N successful posts?
3. **Volume target:** How many videos per day? (3-5 recommended to start)
4. **Platform priority:** TikTok only, or cross-post to Instagram/YouTube?
5. **Avatar style:** Realistic, stylized, or cartoon? Based on you or distinct?

---

*Session completed: 2026-02-28 02:30 GMT+8*
