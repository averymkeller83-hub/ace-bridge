# Learning Session: Self-Improving AI Agents

**Date:** 2026-03-01  
**Topic:** Reflection, self-correction, and auto-curricula

---

## Core Principle

> "Agents shouldn't be static models with fixed prompts. They should practice, reflect, generate their own curricula, and rewrite parts of themselves."

---

## Six Mechanisms of Self-Improvement

### 1. Self-Reflection and In-Loop Feedback

**Reflexion (Shinn et al., 2023)**
```
Task → Attempt → Check → Failed
         ↓
    Write critique (natural language)
         ↓
    Store reflection
         ↓
    Retry with reflection
```

**Results:** HumanEval pass@1: GPT-4 baseline → ~91%

**Pros:**
- No weight updates (cheap)
- Large gains for small effort

**Cons:**
- Improvements ephemeral unless persisted
- Can hallucinate bad reflections

**Self-Refine (Madaan et al., 2023)**
- Generate → Critique → Revise (repeat until convergence)

---

### 2. Learning to Self-Correct

**RISE - Recursive Introspection (Qu et al., 2024)**
- Fine-tune on multi-turn traces: wrong answer → feedback → correction
- Model learns to simulate introspection internally
- Self-correction becomes built-in capability

**STaR - Self-Taught Reasoner (Zelikman et al., 2022)**
```
1. Generate many solutions
2. Filter for correct ones
3. Fine-tune on reasoning paths
4. Repeat
```
- Small models become strong reasoners from own proofs

**STaSC - Self-Taught Self-Correction (2025)**
- LM generates answer → correction
- Fine-tune on corrected outputs
- No human labels needed
- 2B models close gap with much larger baselines

---

### 3. Self-Generated Data and Auto-Curricula

**Self-Challenging Agents (NeurIPS 2025)**

Two roles:
- **Challenger:** Creates tasks with verified test code
- **Executor:** Solves tasks, gets scalar reward from tests

**Loop:**
```
Challenger creates task + tests
         ↓
Executor attempts solution
         ↓
Tests verify (pass/fail)
         ↓
Success → Training data
         ↓
RL on self-generated data
```

**Results:** Doubles performance on tool-use benchmarks

**Pros:**
- Fully label-free
- Tasks scale with capability
- Precise feedback from tests

**Cons:**
- Needs domains with verifiable tests
- Risk of curriculum collapse (staying in comfort zone)

---

### 4. Self-Generated In-Context Examples

**Sarukkai et al. (NeurIPS 2025)**

Simple but powerful:
1. Successfully solve task → store full trajectory
2. Future tasks: prompt with past successful trajectories
3. Experience replay for prompting

**Results:**
- ALFWorld: 73% → 89% (some settings 93%)
- Rivals much larger frozen models

**Pros:**
- Extremely easy to implement
- No gradient updates
- Memory of "how I solved this before"

---

## Design Patterns Summary

| Pattern | Mechanism | Persistence | Complexity |
|---------|-----------|-------------|------------|
| Reflexion | Natural language critique | Store reflections | Low |
| Self-Refine | Generate-critique-revise loop | None (inference only) | Low |
| RISE | Fine-tune on correction traces | Model weights | Medium |
| STaR | Self-generated reasoning data | Model weights | Medium |
| Self-Challenging | Auto-generated tasks + RL | Model weights | High |
| In-Context Examples | Store successful trajectories | Memory/prompts | Low |

---

## Key Insights

1. **"Learning to improve" can be a training objective**
   - Don't just train for good answers
   - Train for good corrections and reasoning traces

2. **Reflection is a runtime optimization layer**
   - Not long-term learning
   - But large gains for small effort

3. **Self-generated data scales with capability**
   - Better agent → harder tasks → better training
   - Virtuous cycle

4. **Verifiable feedback is crucial**
   - Test code, not just linguistic feedback
   - Precise, non-ambiguous

---

## For Jarvis: Implementation Path

### Phase 1: Reflection (Immediate)
```python
def execute_with_reflection(task):
    # Attempt task
    result = execute(task)
    
    # Self-evaluate
    critique = generate_critique(task, result)
    
    # Store reflection
    memory.store_reflection(task, critique)
    
    # Retry if needed
    if not success:
        return execute_with_reflection(task, context=critique)
```

### Phase 2: Success Trajectory Memory
```python
# Store successful task completions
memory.store_trajectory(task, steps, result)

# Future similar tasks: retrieve as in-context examples
examples = memory.find_similar_trajectories(new_task)
response = llm.generate(task, context=examples)
```

### Phase 3: Self-Generated Curriculum
```python
# Challenger agent generates tasks
while improving:
    task = challenger.generate_task(current_skill_level)
    result = executor.attempt(task)
    
    if result.success:
        training_data.append((task, result))
        skill_level += 1
    
    # Periodic fine-tuning on successes
    if len(training_data) > threshold:
        model.fine_tune(training_data)
```

---

## Open Questions

1. How to prevent reflection hallucinations?
2. How to ensure curriculum diversity?
3. How to verify success without tests?
4. Safety: How to bound self-modification?

---

**Session Duration:** ~30 minutes  
**Sources:** NeurIPS 2025 papers, Yohei Nakajima synthesis
