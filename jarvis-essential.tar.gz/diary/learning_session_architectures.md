# Learning Session: Advanced AI Agent Architectures

**Date:** 2026-03-01 (Early Morning)  
**Topic:** Cognitive architectures and multi-agent systems

---

## Key Finding: Unified Taxonomy for Agentic AI

Research from University of Melbourne (2025) proposes 6 modular dimensions:

```
┌─────────────────────────────────────────────────────────────┐
│                    AGENTIC AI TAXONOMY                      │
├─────────────────────────────────────────────────────────────┤
│ 1. Core Components                                          │
│    - Perception (input processing)                          │
│    - Memory (short/long-term, episodic/semantic)            │
│    - Action (output generation)                             │
│    - Profiling (agent persona/identity)                     │
├─────────────────────────────────────────────────────────────┤
│ 2. Cognitive Architecture                                   │
│    - Planning (reasoning, goal decomposition)               │
│    - Reflection (self-evaluation, learning)                 │
├─────────────────────────────────────────────────────────────┤
│ 3. Learning                                                 │
│    - From feedback                                          │
│    - From demonstration                                     │
│    - From exploration                                       │
├─────────────────────────────────────────────────────────────┤
│ 4. Multi-Agent Systems                                      │
│    - Collaboration patterns                                 │
│    - Communication protocols                                │
│    - Coordination mechanisms                                │
├─────────────────────────────────────────────────────────────┤
│ 5. Environments                                             │
│    - Digital (OS, web, APIs)                                │
│    - Embodied (robotics, physical)                          │
│    - Specialized (scientific, creative)                     │
├─────────────────────────────────────────────────────────────┤
│ 6. Evaluation                                               │
│    - Task completion                                        │
│    - Safety metrics                                         │
│    - Efficiency measures                                    │
└─────────────────────────────────────────────────────────────┘
```

---

## Major Shifts in 2025

### 1. From Generative to Agentic AI

| Generative AI | Agentic AI |
|---------------|------------|
| Maps input → output | Perceives → Reasons → Plans → Acts |
| Static responses | Changes environment state |
| Single-turn | Extended goal pursuit |
| Passive knowledge | Active collaboration |

### 2. Inference-Time Reasoning Models

- Configurable reasoning budgets
- Native reasoning behaviors (o1, o3, Claude 3.7 Sonnet)
- Changes how planners/controllers are built

### 3. From Function Calling to Code-as-Action

**Old:** JSON function calls
```json
{"name": "search", "params": {"query": "AI"}}
```

**New:** Code execution
```python
results = search("AI", limit=10)
for r in results:
    print(r.title)
```

### 4. Native Computer Use

Agents operate UIs through:
- Screenshots (perception)
- Mouse/keyboard actions (action)
- Can use any software humans use

### 5. Standardized Tool Connectivity (MCP)

- Common protocol for exposing tools
- Reduces connector fragmentation
- Enables governance (allowlists, audit logging)

---

## Architecture Patterns

### Pattern 1: Single Loop (ReAct)
```
Thought → Action → Observation → ... → Answer
```

### Pattern 2: Hierarchical Multi-Agent
```
        Orchestrator
       /     |     \
  Agent1   Agent2   Agent3
```

### Pattern 3: Flow Engineering
```
Explicit state machine with guardrails:
Start → [Check] → Process → [Verify] → End
         ↓ fail          ↓ fail
       Escalate        Retry
```

### Pattern 4: Agents Hierarchy + Loop + Parallel + Shared RAG
```
┌─────────────────────────────────────────┐
│           Shared RAG Store              │
└─────────────────────────────────────────┘
         ↓           ↓           ↓
    ┌────────┐  ┌────────┐  ┌────────┐
    │ Agent  │  │ Agent  │  │ Agent  │
    │ Loop   │  │ Loop   │  │ Loop   │
    └────────┘  └────────┘  └────────┘
         ↓           ↓           ↓
    └─────────────────────────────────┘
│         Parallel Execution          │
└─────────────────────────────────────┘
```

---

## Open Challenges

| Challenge | Description |
|-----------|-------------|
| **Hallucination in Action** | Wrong actions, not just wrong text |
| **Infinite Loops** | Agents that never terminate |
| **Prompt Injection** | Malicious instructions in untrusted content |
| **Safety at Scale** | Controlling agents with broad permissions |
| **Evaluation Gaps** | Hard to measure real-world performance |

---

## Implications for Jarvis

### Current Alignment with Taxonomy

| Dimension | Status | Notes |
|-----------|--------|-------|
| Core Components | ✅ Strong | Memory, perception, action implemented |
| Cognitive Architecture | ⚠️ Partial | Planning ad-hoc, reflection minimal |
| Learning | ⚠️ Basic | Episodic memory, no active learning |
| Multi-Agent | ✅ Good | Hierarchical with orchestration |
| Environment | ✅ Good | Digital (OS, web, APIs) |
| Evaluation | ❌ Weak | No formal metrics yet |

### Recommended Upgrades

1. **Explicit Planning Module**
   - Goal decomposition
   - Plan validation
   - Checkpoint/resume

2. **Reflection System**
   - Self-evaluation after tasks
   - Success/failure analysis
   - Strategy adjustment

3. **Active Learning**
   - Learn from successes/failures
   - Preference learning from user feedback
   - Tool use optimization

4. **Formal Evaluation**
   - Task completion metrics
   - Efficiency tracking
   - Safety monitoring

---

## Research Sources

- Arunkumar V & Rajkumar Buyya, University of Melbourne (2026)
- "Agentic Artificial Intelligence: Architectures, Applications, and Challenges"

---

**Session Duration:** ~25 minutes  
**Next Topic:** Planning to research reflection systems and active learning for agents
