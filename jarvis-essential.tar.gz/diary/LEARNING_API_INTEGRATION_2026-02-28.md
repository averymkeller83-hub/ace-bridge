# Learning Session: YouTube & Etsy API Integration
**Date:** 2026-02-28 (Early Morning)  
**For:** Building API integration skills  
**Goal:** Research YouTube Data API and Etsy API v3 for automation

---

## YouTube Data API

### Key Capabilities

**Uploads:**
- Upload videos with metadata (title, description, tags, privacy)
- Set thumbnails
- Schedule publish times
- Manage playlists

**Analytics:**
- View metrics (views, likes, comments)
- Audience retention
- Traffic sources
- Revenue data (if monetized)

**Comments:**
- Retrieve comments
- Reply to comments
- Moderate (delete, mark spam)

### Rate Limits (as of 2026)
- Default quota: 10,000 units per day
- Upload: 1600 units per video
- Search: 100 units per request
- Read operations: 1-5 units each

### Key Endpoints

```
POST /youtube/v3/videos              # Upload
GET  /youtube/v3/channels            # Channel info
GET  /youtube/v3/playlistItems       # Playlist videos
GET  /youtube/v3/commentThreads      # Comments
POST /youtube/v3/commentThreads      # Post comment
```

### Python Example

```python
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload

youtube = build('youtube', 'v3', credentials=creds)

# Upload video
request_body = {
    'snippet': {
        'title': 'My Video',
        'description': 'Video description',
        'tags': ['tag1', 'tag2'],
        'categoryId': '22'  # People & Blogs
    },
    'status': {
        'privacyStatus': 'private',  # private, public, unlisted
        'publishAt': '2026-03-01T12:00:00Z'  # Optional schedule
    }
}

media = MediaFileUpload('video.mp4', chunksize=-1, resumable=True)
response = youtube.videos().insert(
    part='snippet,status',
    body=request_body,
    media_body=media
).execute()
```

---

## Etsy API v3

### Key Capabilities

**Listings:**
- Create, update, delete listings
- Manage inventory
- Update pricing
- Upload images

**Orders:**
- Retrieve orders
- Update shipment status
- Print shipping labels
- Handle cancellations

**Shop:**
- Get shop stats
- Update shop policies
- Manage sections

**Reviews:**
- Get reviews
- Respond to reviews

### Authentication
- OAuth 2.0 required
- Scopes: listings_r, listings_w, transactions_r, etc.
- API key + OAuth token

### Rate Limits
- 1000 requests per 24 hours for most endpoints
- Stricter limits for some write operations

### Key Endpoints

```
GET  /v3/application/shops/{shop_id}/listings
POST /v3/application/listings
GET  /v3/application/shops/{shop_id}/receipts
POST /v3/application/receipts/{receipt_id}/tracking
```

### Python Example

```python
import requests

headers = {
    'x-api-key': ETSY_API_KEY,
    'Authorization': f'Bearer {oauth_token}'
}

# Get listings
response = requests.get(
    f'https://openapi.etsy.com/v3/application/shops/{shop_id}/listings',
    headers=headers
)
listings = response.json()['results']

# Create listing
new_listing = {
    'title': 'Handmade Ceramic Mug',
    'description': 'Beautiful handmade mug...',
    'price': 35.00,
    'quantity': 5,
    'taxonomy_id': 1,  # Ceramics
    'who_made': 'i_did',
    'when_made': 'made_to_order',
    'is_supply': False,
    'shipping_template_id': 12345
}

response = requests.post(
    'https://openapi.etsy.com/v3/application/listings',
    headers=headers,
    json=new_listing
)
```

---

## Integration Architecture

### Proposed Skill Structure

```
youtube-integration/
├── SKILL.md
├── scripts/
│   ├── youtube_client.py      # Core API client
│   ├── upload_video.py        # Upload workflow
│   ├── analytics.py           # Metrics retrieval
│   └── requirements.txt
└── references/
    ├── api_reference.md
    └── examples/

etsy-integration/
├── SKILL.md
├── scripts/
│   ├── etsy_client.py         # Core API client
│   ├── listings.py            # Listing management
│   ├── orders.py              # Order processing
│   └── requirements.txt
└── references/
    ├── api_reference.md
    └── examples/
```

### Common Patterns

**1. OAuth Integration:**
```python
from oauth_manager import OAuthManager

oauth = OAuthManager()
token = oauth.get_token('youtube')
# Use token in API calls
```

**2. Memory Integration:**
```python
from agent_memory import AgentMemory

memory = AgentMemory('youtube-agent')
memory.remember('last_upload', video_id, 'episodic')
```

**3. Error Handling:**
- Rate limit detection
- Exponential backoff
- Token refresh on 401
- Retry with circuit breaker

**4. Async Operations:**
- Video uploads are slow
- Use async/await or background tasks
- Progress tracking
- Completion callbacks

---

## Automation Workflows

### YouTube Upload Workflow

1. **Prepare Content**
   - Get video file path
   - Read metadata (title, description, tags)
   - Validate thumbnail

2. **Check Quota**
   - Verify sufficient quota remaining
   - Alert if low

3. **Upload**
   - Start resumable upload
   - Track progress
   - Handle interruptions

4. **Post-Upload**
   - Set thumbnail
   - Add to playlist (optional)
   - Store video ID in memory
   - Notify completion

### Etsy Listing Workflow

1. **Prepare Listing**
   - Get product details
   - Upload images
   - Set pricing
   - Configure shipping

2. **Validate**
   - Check required fields
   - Verify images
   - Test shipping template

3. **Create Draft**
   - POST to listings endpoint
   - Store draft ID

4. **Review (Optional)**
   - Present to user for approval
   - Or auto-publish

5. **Publish**
   - Update status to active
   - Store listing ID
   - Track in memory

---

## Implementation Priority

### Phase 1: Core Clients
- [ ] YouTube client with OAuth
- [ ] Etsy client with OAuth
- [ ] Basic CRUD operations
- [ ] Error handling

### Phase 2: Workflows
- [ ] Video upload with progress
- [ ] Listing creation
- [ ] Analytics retrieval
- [ ] Order processing

### Phase 3: Automation
- [ ] Scheduled uploads
- [ ] Inventory sync
- [ ] Comment moderation
- [ ] Report generation

---

## Open Questions

1. Should uploads be synchronous or async?
2. How to handle large video files?
3. Should we cache API responses?
4. What analytics matter most?
5. How to handle Etsy variations (size, color)?

---

*Session completed: 2026-02-28 01:30 GMT+8*
