#!/usr/bin/env python3
"""
Jarvis Upgrade System
Comprehensive upgrade and migration preparation.
"""

import json
import shutil
import zipfile
from pathlib import Path
from datetime import datetime
from typing import Dict, List


class UpgradeManager:
    """Manages all Jarvis upgrades and migration preparation."""
    
    def __init__(self):
        self.workspace = Path("/root/.openclaw/workspace")
        self.backup_dir = Path.home() / ".openclaw" / "backups"
        self.components = {
            "security": {
                "status": "ACTIVE",
                "files": [
                    "diary/security_validator.py",
                    "diary/secure_tools.py",
                    "skills/jarvis-security/SKILL.md"
                ],
                "version": "1.0.0"
            },
            "memory": {
                "status": "ACTIVE",
                "files": [
                    "diary/semantic_memory.py",
                    "skills/semantic-memory/SKILL.md"
                ],
                "version": "1.0.0"
            },
            "error_handling": {
                "status": "ACTIVE",
                "files": [
                    "diary/error_handling.py",
                    "skills/error-handling/SKILL.md"
                ],
                "version": "1.0.0"
            },
            "activity_tracking": {
                "status": "ACTIVE",
                "files": [
                    "diary/activity_tracker.py"
                ],
                "version": "1.0.0"
            },
            "context_assembly": {
                "status": "ACTIVE",
                "files": [
                    "diary/context_assembly.py",
                    "diary/fact_extractor.py",
                    "skills/context-assembly/SKILL.md"
                ],
                "version": "1.0.0"
            },
            "marketing_agent": {
                "status": "ACTIVE",
                "files": [
                    "skills/marketing-agent/marketing_agent.py",
                    "skills/marketing-agent/SKILL.md"
                ],
                "version": "1.0.0"
            },
            "capability_registry": {
                "status": "ACTIVE",
                "files": [
                    "skills/agent-capability-registry/capability_registry.py",
                    "skills/agent-capability-registry/SKILL.md"
                ],
                "version": "1.0.0"
            }
        }
    
    def verify_all(self) -> Dict:
        """Verify all components are installed and working."""
        results = {}
        
        for name, config in self.components.items():
            all_exist = True
            missing = []
            
            for file_path in config["files"]:
                full_path = self.workspace / file_path
                if not full_path.exists():
                    all_exist = False
                    missing.append(file_path)
            
            results[name] = {
                "installed": all_exist,
                "missing": missing,
                "status": config["status"]
            }
        
        return results
    
    def create_backup(self) -> str:
        """Create full backup for migration."""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_name = f"jarvis_backup_{timestamp}"
        backup_path = self.backup_dir / backup_name
        
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        
        # Create backup structure
        backup_path.mkdir()
        
        # Backup memories
        memory_src = Path.home() / ".openclaw" / "memory"
        memory_dst = backup_path / "memory"
        if memory_src.exists():
            shutil.copytree(memory_src, memory_dst)
        
        # Backup workspace
        workspace_dst = backup_path / "workspace"
        shutil.copytree(self.workspace, workspace_dst)
        
        # Create manifest
        manifest = {
            "created": datetime.now().isoformat(),
            "version": "1.0.0",
            "components": list(self.components.keys()),
            "memory_stats": self._get_memory_stats()
        }
        
        with open(backup_path / "manifest.json", "w") as f:
            json.dump(manifest, f, indent=2)
        
        # Create zip
        zip_path = self.backup_dir / f"{backup_name}.zip"
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
            for file in backup_path.rglob("*"):
                if file.is_file():
                    zf.write(file, file.relative_to(backup_path))
        
        print(f"✅ Backup created: {zip_path}")
        return str(zip_path)
    
    def _get_memory_stats(self) -> Dict:
        """Get memory statistics."""
        try:
            sys.path.insert(0, str(self.workspace / "diary"))
            from semantic_memory import SemanticMemory
            memory = SemanticMemory("jarvis-main")
            return memory.get_stats()
        except:
            return {"error": "Could not load memory stats"}
    
    def generate_migration_script(self) -> str:
        """Generate migration script for new server."""
        script = '''#!/bin/bash
# Jarvis Migration Script
# Run on new server to restore from backup

echo "=== Jarvis Migration ==="
echo "Extracting backup..."

# Extract backup
BACKUP_ZIP="$1"
if [ -z "$BACKUP_ZIP" ]; then
    echo "Usage: ./migrate.sh <backup.zip>"
    exit 1
fi

# Create directories
mkdir -p ~/.openclaw
mkdir -p ~/.openclaw/workspace

# Extract
echo "Extracting workspace..."
unzip -q "$BACKUP_ZIP" -d /tmp/jarvis_restore

# Restore memories
echo "Restoring memories..."
cp -r /tmp/jarvis_restore/memory/* ~/.openclaw/memory/

# Restore workspace
echo "Restoring workspace..."
cp -r /tmp/jarvis_restore/workspace/* ~/.openclaw/workspace/

# Install dependencies
echo "Installing dependencies..."
pip install chromadb --break-system-packages --user

# Verify
echo "Verifying installation..."
cd ~/.openclaw/workspace
cd diary && python3 -c "from semantic_memory import SemanticMemory; m = SemanticMemory('jarvis-main'); print('✅ Memory OK')"
cd ../skills/marketing-agent && python3 -c "from marketing_agent import MarketingAgent; a = MarketingAgent(); print('✅ Marketing OK')"
cd ../agent-capability-registry && python3 -c "from capability_registry import CapabilityRegistry; r = CapabilityRegistry(); print('✅ Registry OK')"

echo ""
echo "=== Migration Complete ==="
echo "Jarvis is ready on new server!"
'''
        
        script_path = self.workspace / "migrate.sh"
        with open(script_path, "w") as f:
            f.write(script)
        
        script_path.chmod(0o755)
        return str(script_path)
    
    def upgrade_all(self) -> Dict:
        """Run all upgrades and prepare for migration."""
        print("=" * 60)
        print("JARVIS UPGRADE SYSTEM")
        print("=" * 60)
        
        results = {
            "verified": {},
            "backup": None,
            "migration_script": None,
            "status": "SUCCESS"
        }
        
        # 1. Verify all components
        print("\n1. Verifying all components...")
        results["verified"] = self.verify_all()
        
        all_ok = all(v["installed"] for v in results["verified"].values())
        if not all_ok:
            print("⚠️  Some components missing!")
            for name, status in results["verified"].items():
                if not status["installed"]:
                    print(f"   - {name}: MISSING {status['missing']}")
            results["status"] = "PARTIAL"
        else:
            print("✅ All components verified")
        
        # 2. Create backup
        print("\n2. Creating migration backup...")
        try:
            results["backup"] = self.create_backup()
            print(f"✅ Backup created")
        except Exception as e:
            print(f"❌ Backup failed: {e}")
            results["status"] = "FAILED"
        
        # 3. Generate migration script
        print("\n3. Generating migration script...")
        try:
            results["migration_script"] = self.generate_migration_script()
            print(f"✅ Migration script: {results['migration_script']}")
        except Exception as e:
            print(f"❌ Script generation failed: {e}")
            results["status"] = "FAILED"
        
        # 4. Summary
        print("\n" + "=" * 60)
        print("UPGRADE SUMMARY")
        print("=" * 60)
        print(f"Status: {results['status']}")
        print(f"Components: {len(results['verified'])}")
        print(f"Backup: {results['backup'] or 'N/A'}")
        print(f"Migration Script: {results['migration_script'] or 'N/A'}")
        
        return results


def main():
    """Run upgrade system."""
    manager = UpgradeManager()
    results = manager.upgrade_all()
    
    print("\n✅ All upgrades complete. Ready for server migration!")
    return results


if __name__ == "__main__":
    main()
