#!/usr/bin/env python3
"""
Semantic Memory - Hybrid Implementation
Works with or without ChromaDB installed.
"""

import sys
from pathlib import Path
from typing import List, Dict, Any, Optional

# Add paths
sys.path.insert(0, str(Path(__file__).parent))
sys.path.insert(0, str(Path(__file__).parent.parent / "skills" / "agent-memory" / "scripts"))

from agent_memory import AgentMemory


class SemanticMemory:
    """
    Memory system with semantic search capabilities.
    Uses ChromaDB if available, falls back to keyword search.
    """
    
    def __init__(self, agent_id: str = "jarvis-main"):
        self.agent_id = agent_id
        self.base_memory = AgentMemory(agent_id)
        self.chroma_available = False
        self.collection = None
        
        # Try to initialize ChromaDB
        self._try_init_chroma()
    
    def _try_init_chroma(self):
        """Attempt to initialize ChromaDB."""
        try:
            import chromadb
            from chromadb.config import Settings
            
            persist_dir = Path.home() / ".openclaw" / "memory" / "chroma"
            persist_dir.mkdir(parents=True, exist_ok=True)
            
            client = chromadb.PersistentClient(
                path=str(persist_dir),
                settings=Settings(anonymized_telemetry=False)
            )
            
            self.collection = client.get_or_create_collection(
                name=f"agent_{self.agent_id}",
                metadata={"agent_id": self.agent_id}
            )
            
            self.chroma_available = True
            print(f"✅ ChromaDB initialized for {self.agent_id}")
            
        except Exception as e:
            self.chroma_available = False
            print(f"⚠️  ChromaDB not available: {e}")
            print("   Falling back to keyword search")
    
    def remember(self, text: str, memory_type: str = "semantic", 
                 metadata: Dict = None, key: str = None):
        """Store a memory."""
        from datetime import datetime
        
        # Store in base memory
        memory_key = key or f"{memory_type}_{datetime.now().isoformat()}"
        self.base_memory.remember(
            key=memory_key,
            value=text,
            category=memory_type,
            metadata=metadata
        )
        
        # Store in ChromaDB if available
        if self.chroma_available and self.collection:
            try:
                import hashlib
                doc_id = hashlib.md5(text.encode()).hexdigest()[:12]
                
                meta = {
                    "type": memory_type,
                    "key": memory_key,
                    "timestamp": datetime.now().isoformat()
                }
                if metadata:
                    meta.update({k: str(v) for k, v in metadata.items()})
                
                self.collection.add(
                    documents=[text],
                    metadatas=[meta],
                    ids=[doc_id]
                )
            except Exception as e:
                pass  # Silent fail for ChromaDB
    
    def recall(self, query: str, memory_type: str = None, 
               n_results: int = 5) -> List[Dict]:
        """Recall memories using semantic + keyword search."""
        results = []
        seen_texts = set()
        
        # 1. Semantic search via ChromaDB
        if self.chroma_available and self.collection:
            try:
                where_filter = {"type": memory_type} if memory_type else None
                
                chroma_results = self.collection.query(
                    query_texts=[query],
                    n_results=n_results * 2,  # Get more to deduplicate
                    where=where_filter
                )
                
                for i, doc in enumerate(chroma_results["documents"][0]):
                    if doc not in seen_texts:
                        seen_texts.add(doc)
                        meta = chroma_results["metadatas"][0][i]
                        distance = chroma_results["distances"][0][i]
                        
                        results.append({
                            "text": doc,
                            "metadata": meta,
                            "source": "semantic",
                            "relevance": max(0, 1 - distance)
                        })
            except Exception as e:
                pass
        
        # 2. Keyword search via base memory
        try:
            keyword_results = self.base_memory.search(query, category=memory_type)
            
            for r in keyword_results:
                text = r.get("value", "")
                if text not in seen_texts:
                    seen_texts.add(text)
                    results.append({
                        "text": text,
                        "metadata": r,
                        "source": "keyword",
                        "relevance": 0.6
                    })
        except Exception as e:
            pass
        
        # Sort by relevance and return
        results.sort(key=lambda x: x["relevance"], reverse=True)
        return results[:n_results]
    
    def get_stats(self) -> Dict:
        """Get memory statistics."""
        stats = {
            "agent_id": self.agent_id,
            "chroma_available": self.chroma_available,
        }
        
        # Count base memories
        try:
            semantic = self.base_memory.get_by_category("semantic")
            episodic = self.base_memory.get_by_category("episodic")
            stats["semantic_memories"] = len(semantic)
            stats["episodic_memories"] = len(episodic)
        except:
            stats["semantic_memories"] = 0
            stats["episodic_memories"] = 0
        
        # Count ChromaDB memories
        if self.chroma_available and self.collection:
            try:
                stats["chroma_count"] = self.collection.count()
            except:
                stats["chroma_count"] = 0
        
        return stats


def test():
    """Test semantic memory."""
    print("=" * 60)
    print("Semantic Memory Test")
    print("=" * 60)
    
    memory = SemanticMemory("jarvis-main")
    
    # Show stats
    stats = memory.get_stats()
    print(f"\nStatus: ChromaDB={'✅' if stats['chroma_available'] else '❌'}")
    print(f"Current memories: {stats.get('semantic_memories', 0)} semantic, {stats.get('episodic_memories', 0)} episodic")
    
    # Test recall on existing memories
    print("\nTesting recall:")
    queries = ["Avery", "project", "Etsy", "timezone"]
    
    for query in queries:
        results = memory.recall(query, n_results=2)
        if results:
            print(f"\n  Query: '{query}'")
            for r in results:
                print(f"    [{r['source']}] {r['text'][:50]}...")


if __name__ == "__main__":
    test()
