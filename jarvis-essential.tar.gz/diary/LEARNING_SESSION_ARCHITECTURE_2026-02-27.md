# Learning Session: OAuth & Agent Memory Architecture
**Date:** 2026-02-27 (Late Night)  
**For:** Jarvis skill development  
**Goal:** Design OAuth skill and agent memory system for Avery's server migration

---

## Part 1: OAuth Skill Design

### Requirements from Conversation with Avery

**Context:**
- Server will host Jarvis with access to Avery's digital life
- Services: Email, YouTube, Etsy, websites, control panel
- Security is critical — server will hold tokens to entire digital presence
- OAuth is the chosen authentication method
- Need secure token storage, refresh logic, per-service clients

### OAuth 2.0 Flows Needed

1. **Authorization Code Flow** (Primary)
   - For: YouTube (Google), Etsy, most web services
   - Secure, redirect-based, supports refresh tokens
   - PKCE extension for additional security

2. **Device Authorization Grant** (Secondary)
   - For: TV/device-limited inputs
   - May be useful for headless server setup

3. **Client Credentials** (Service-to-service)
   - For: Internal APIs, control panel
   - No user interaction required

### Token Security Architecture

**Storage:**
```
~/.openclaw/secrets/
├── oauth/
│   ├── google_tokens.enc    # YouTube, Gmail
│   ├── etsy_tokens.enc      # Etsy shop
│   ├── internal_tokens.enc  # Control panel
│   └── master.key           # Encryption key (separate from tokens)
```

**Security Measures:**
- AES-256-GCM encryption at rest
- Master key stored separately (environment variable or TPM)
- Tokens never logged, never in memory longer than necessary
- Automatic rotation on refresh
- Audit log of all token usage (what, when, success/failure)

### Token Lifecycle Management

```
[Authorize] → [Store Encrypted] → [Use] → [Refresh if expired] → [Revoke on logout]
     ↑                                                              ↓
     └────────────────── Auto-refresh on 401 ──────────────────────┘
```

**Health Monitoring:**
- Check token expiry 24h before expiration
- Alert if refresh fails
- Graceful degradation (notify user, request re-auth)

### Per-Service Configuration

Each service needs:
- Client ID/Secret (from developer console)
- Authorization endpoint
- Token endpoint
- Scopes required
- Refresh token support (yes/no)
- Rate limits

**Example: YouTube Data API**
```yaml
youtube:
  provider: google
  client_id: ${GOOGLE_CLIENT_ID}
  client_secret: ${GOOGLE_CLIENT_SECRET}
  scopes:
    - https://www.googleapis.com/auth/youtube.upload
    - https://www.googleapis.com/auth/youtube.readonly
    - https://www.googleapis.com/auth/youtube.force-ssl
  auth_endpoint: https://accounts.google.com/o/oauth2/v2/auth
  token_endpoint: https://oauth2.googleapis.com/token
  refreshable: true
```

### Skill Interface Design

```python
# oauth_skill.py

class OAuthManager:
    def authorize(self, service: str) -> AuthResult:
        """Start OAuth flow for a service"""
        
    def get_token(self, service: str) -> Token:
        """Get valid token (auto-refresh if needed)"""
        
    def revoke(self, service: str) -> bool:
        """Revoke tokens for a service"""
        
    def health_check(self) -> HealthReport:
        """Check all token statuses"""
```

---

## Part 2: Agent Memory System Design

### Requirements from Conversation

- Each agent has its own isolated memory
- Persistent across sessions
- Retrievable and searchable
- Supports the "one project rule" enforcement

### Memory Architecture

```
~/.openclaw/memory/
├── agents/
│   ├── jarvis-main/           # Main assistant memory
│   │   ├── conversations/     # Full conversation history
│   │   ├── facts.jsonl        # Extracted facts about user
│   │   ├── preferences.json   # User preferences
│   │   └── projects/          # Project tracking
│   │
│   ├── oauth-agent/           # OAuth-specific agent
│   │   ├── auth_attempts.log
│   │   └── token_health.json
│   │
│   ├── etsy-agent/            # Etsy shop management
│   │   ├── listings/
│   │   ├── orders/
│   │   └── customer_interactions/
│   │
│   └── youtube-agent/         # YouTube management
│       ├── uploads/
│       ├── analytics/
│       └── comments/
│
├── shared/                    # Cross-agent knowledge
│   ├── user_profile.json
│   └── project_parking_lot.json
```

### Memory Types

1. **Episodic Memory** — Conversation history
   - Full logs per session
   - Summaries for long-term reference
   - Key decisions and their context

2. **Semantic Memory** — Facts and knowledge
   - User preferences
   - Business rules
   - Service configurations
   - Learned patterns

3. **Procedural Memory** — How-to knowledge
   - Workflows (how to upload a video)
   - Checklists (pre-publish review)
   - Error recovery procedures

4. **Project Memory** — Active work tracking
   - Current project status
   - Next actions
   - Blockers
   - Decisions made

### Memory Interface

```python
# memory_skill.py

class AgentMemory:
    def __init__(self, agent_id: str):
        self.agent_id = agent_id
        
    def remember(self, key: str, value: Any, category: str = "general"):
        """Store a memory"""
        
    def recall(self, key: str) -> Any:
        """Retrieve a specific memory"""
        
    def search(self, query: str, category: str = None) -> List[Memory]:
        """Search memories by content"""
        
    def summarize(self, timeframe: str) -> str:
        """Get summary of recent activity"""
        
    def get_project_status(self, project_id: str) -> ProjectStatus:
        """Get full status of a tracked project"""
```

### Project Tracking Integration

From the prioritization research, the memory system needs to support:

1. **ICE Scoring Storage**
   - Project ideas with scores
   - Re-scoring history
   - Decision rationale

2. **Parking Lot Management**
   - Parked projects with restart conditions
   - Queue order
   - Dependencies between projects

3. **Active Project Tracking**
   - Daily progress
   - Time spent
   - Blockers
   - Next actions

4. **Enforcement Support**
   - "Are you sure?" prompts for new projects
   - Current project reminders
   - Completion celebrations

---

## Implementation Priority

### Phase 1: Foundation (This Week)
1. OAuth skill — Core authentication
2. Memory skill — Basic storage/retrieval
3. Project tracking — ICE scoring, parking lot

### Phase 2: Service Integration (Next)
1. YouTube API skill
2. Etsy API skill
3. Email management skill

### Phase 3: Automation (Later)
1. Workflow automation
2. Monitoring/alerting
3. Advanced project management

---

## Open Questions

1. Should the memory system use embeddings for semantic search?
2. How long should conversation history be retained?
3. Should there be a "memory consolidation" process (summarize old memories)?
4. How to handle sensitive memories (passwords, API keys separate from general memory)?

---

## Next Steps

1. Build OAuth skill core (encryption, token management)
2. Build Memory skill core (storage, retrieval, search)
3. Integrate both for the prioritization/project tracking system
4. Test with a simple service (maybe email first)

---

*Session completed: 2026-02-27 23:30 GMT+8*
