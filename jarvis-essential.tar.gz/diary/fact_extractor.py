#!/usr/bin/env python3
"""
Automatic Fact Extraction for Jarvis
Extracts user preferences and facts from conversations.
Uses pattern matching (fast) + LLM extraction (comprehensive).
"""

import json
import re
from typing import List, Dict, Optional
from dataclasses import dataclass, asdict


@dataclass
class ExtractedFact:
    """A fact extracted from conversation."""
    key: str
    value: str
    category: str  # "preference", "fact", "relationship", "goal"
    confidence: float  # 0.0 to 1.0
    source: str  # The conversation snippet that yielded this fact
    
    def to_dict(self) -> Dict:
        return asdict(self)


class FactExtractor:
    """Extracts facts from conversations."""
    
    def __init__(self):
        # Regex patterns for common facts
        self.patterns = {
            "name": [
                r"my name is (\w+)",
                r"call me (\w+)",
                r"i am (\w+) (?:and |from |who |\.|$)",
            ],
            "timezone": [
                r"my timezone is ([\w/+-]+)",
                r"i am in ([\w/+-]+) (?:time|timezone)",
                r"(?:gmt|utc)([+-]\d+)",
            ],
            "location": [
                r"i (?:live in|am from|am in) ([\w, ]+)",
                r"located in ([\w, ]+)",
            ],
            "job": [
                r"i (?:work as|am a|work in) ([\w, ]+)",
                r"my job is ([\w, ]+)",
            ],
            "preference_like": [
                r"i (?:like|love|enjoy|prefer) ([\w ]+?)(?:\.|,| and |$)",
                r"my favorite ([\w]+) is ([\w ]+?)(?:\.|,| and |$)",
            ],
            "preference_dislike": [
                r"i (?:dislike|hate|don't like|can't stand) ([\w ]+?)(?:\.|,| and |$)",
            ],
            "communication": [
                r"(?:keep it|be) (short|brief|concise|detailed|verbose)",
                r"i prefer (short|brief|concise|detailed|verbose) (?:answers|responses)",
            ]
        }
    
    def extract_with_patterns(self, user_text: str) -> List[ExtractedFact]:
        """Fast regex-based extraction (no LLM needed)."""
        facts = []
        text_lower = user_text.lower()
        
        # Name
        for pattern in self.patterns["name"]:
            match = re.search(pattern, text_lower)
            if match:
                facts.append(ExtractedFact(
                    key="name", value=match.group(1).capitalize(),
                    category="fact", confidence=0.9, source=user_text[:100]
                ))
                break
        
        # Timezone
        for pattern in self.patterns["timezone"]:
            match = re.search(pattern, text_lower)
            if match:
                tz = match.group(1).upper()
                if not tz.startswith(("GMT", "UTC")):
                    tz = f"GMT{tz}"
                facts.append(ExtractedFact(
                    key="timezone", value=tz,
                    category="fact", confidence=0.85, source=user_text[:100]
                ))
                break
        
        # Location
        for pattern in self.patterns["location"]:
            match = re.search(pattern, text_lower)
            if match:
                facts.append(ExtractedFact(
                    key="location", value=match.group(1).strip(),
                    category="fact", confidence=0.8, source=user_text[:100]
                ))
                break
        
        # Job
        for pattern in self.patterns["job"]:
            match = re.search(pattern, text_lower)
            if match:
                facts.append(ExtractedFact(
                    key="job", value=match.group(1).strip(),
                    category="fact", confidence=0.75, source=user_text[:100]
                ))
                break
        
        # Preferences (likes)
        for pattern in self.patterns["preference_like"]:
            for match in re.finditer(pattern, text_lower):
                if "favorite" in pattern:
                    facts.append(ExtractedFact(
                        key=f"favorite_{match.group(1)}",
                        value=match.group(2),
                        category="preference",
                        confidence=0.85,
                        source=user_text[:100]
                    ))
                else:
                    facts.append(ExtractedFact(
                        key=f"likes_{match.group(1).strip()}",
                        value=match.group(1).strip(),
                        category="preference",
                        confidence=0.8,
                        source=user_text[:100]
                    ))
        
        # Preferences (dislikes)
        for pattern in self.patterns["preference_dislike"]:
            for match in re.finditer(pattern, text_lower):
                facts.append(ExtractedFact(
                    key=f"dislikes_{match.group(1).strip()}",
                    value=match.group(1).strip(),
                    category="preference",
                    confidence=0.8,
                    source=user_text[:100]
                ))
        
        # Communication style
        for pattern in self.patterns["communication"]:
            match = re.search(pattern, text_lower)
            if match:
                facts.append(ExtractedFact(
                    key="communication_style",
                    value=match.group(1),
                    category="communication",
                    confidence=0.85,
                    source=user_text[:100]
                ))
                break
        
        return facts
    
    def extract_all(self, user_text: str) -> List[ExtractedFact]:
        """Extract all facts using patterns (fast path)."""
        return self.extract_with_patterns(user_text)


def test_extraction():
    """Test fact extraction."""
    print("=" * 60)
    print("Testing Automatic Fact Extraction")
    print("=" * 60)
    
    extractor = FactExtractor()
    
    test_inputs = [
        "My name is Avery and I live in California",
        "I prefer concise answers and my timezone is GMT+8",
        "I work as a software engineer and I love hiking",
        "Call me John, I don't like waiting for slow responses",
        "My favorite color is blue and I enjoy reading",
    ]
    
    for text in test_inputs:
        print(f"\nInput: \"{text}\"")
        facts = extractor.extract_all(text)
        if facts:
            print("Extracted facts:")
            for fact in facts:
                print(f"  - {fact.key}: {fact.value} ({fact.category}, confidence={fact.confidence})")
        else:
            print("  No facts extracted")


if __name__ == "__main__":
    test_extraction()
