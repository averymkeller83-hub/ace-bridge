#!/usr/bin/env python3
"""
Error Handling and Retry System for Jarvis
Implements exponential backoff, circuit breaker, and graceful degradation.
"""

import time
import random
import functools
from typing import Callable, Any, Optional, Type, List
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum


class CircuitState(Enum):
    """Circuit breaker states."""
    CLOSED = "closed"      # Normal operation
    OPEN = "open"          # Failing, reject requests
    HALF_OPEN = "half_open"  # Testing if recovered


@dataclass
class RetryConfig:
    """Configuration for retry behavior."""
    max_retries: int = 3
    initial_delay: float = 1.0
    max_delay: float = 60.0
    exponential_base: float = 2.0
    jitter: bool = True
    retryable_exceptions: List[Type[Exception]] = field(default_factory=lambda: [
        ConnectionError, TimeoutError, IOError
    ])


@dataclass
class CircuitBreakerConfig:
    """Configuration for circuit breaker."""
    failure_threshold: int = 5
    recovery_timeout: int = 60
    half_open_max_calls: int = 3


class CircuitBreaker:
    """
    Circuit breaker pattern implementation.
    Prevents cascading failures by stopping calls to failing services.
    """
    
    def __init__(self, name: str, config: CircuitBreakerConfig = None):
        self.name = name
        self.config = config or CircuitBreakerConfig()
        self.state = CircuitState.CLOSED
        self.failure_count = 0
        self.success_count = 0
        self.last_failure_time = None
        self.half_open_calls = 0
        self._lock = False  # Simple lock for thread safety
    
    def _can_execute(self) -> bool:
        """Check if execution should proceed."""
        if self.state == CircuitState.CLOSED:
            return True
        
        if self.state == CircuitState.OPEN:
            # Check if recovery timeout has passed
            if self.last_failure_time:
                elapsed = (datetime.now() - self.last_failure_time).seconds
                if elapsed >= self.config.recovery_timeout:
                    self.state = CircuitState.HALF_OPEN
                    self.half_open_calls = 0
                    return True
            return False
        
        if self.state == CircuitState.HALF_OPEN:
            if self.half_open_calls < self.config.half_open_max_calls:
                self.half_open_calls += 1
                return True
            return False
        
        return True
    
    def _on_success(self):
        """Handle successful execution."""
        if self.state == CircuitState.HALF_OPEN:
            self.success_count += 1
            if self.success_count >= self.config.half_open_max_calls:
                # Recovered! Close the circuit
                self.state = CircuitState.CLOSED
                self.failure_count = 0
                self.success_count = 0
                print(f"[CircuitBreaker] {self.name}: Recovered, circuit CLOSED")
        else:
            self.failure_count = max(0, self.failure_count - 1)
    
    def _on_failure(self):
        """Handle failed execution."""
        self.failure_count += 1
        self.last_failure_time = datetime.now()
        
        if self.state == CircuitState.HALF_OPEN:
            # Failed during testing, open again
            self.state = CircuitState.OPEN
            print(f"[CircuitBreaker] {self.name}: Failed in HALF_OPEN, circuit OPEN")
        elif self.failure_count >= self.config.failure_threshold:
            # Too many failures, open circuit
            self.state = CircuitState.OPEN
            print(f"[CircuitBreaker] {self.name}: Threshold reached, circuit OPEN")
    
    def call(self, func: Callable, *args, **kwargs) -> Any:
        """Execute function with circuit breaker protection."""
        if not self._can_execute():
            raise CircuitBreakerOpenError(
                f"Circuit breaker '{self.name}' is OPEN"
            )
        
        try:
            result = func(*args, **kwargs)
            self._on_success()
            return result
        except Exception as e:
            self._on_failure()
            raise e


class CircuitBreakerOpenError(Exception):
    """Raised when circuit breaker is open."""
    pass


class RetryHandler:
    """Handles retry logic with exponential backoff."""
    
    def __init__(self, config: RetryConfig = None):
        self.config = config or RetryConfig()
    
    def calculate_delay(self, attempt: int) -> float:
        """Calculate delay for retry attempt."""
        # Exponential backoff: initial_delay * (base ^ attempt)
        delay = self.config.initial_delay * (self.config.exponential_base ** attempt)
        delay = min(delay, self.config.max_delay)
        
        # Add jitter to prevent thundering herd
        if self.config.jitter:
            delay = delay * (0.5 + random.random())
        
        return delay
    
    def is_retryable(self, exception: Exception) -> bool:
        """Check if exception is retryable."""
        return any(isinstance(exception, exc_type) 
                  for exc_type in self.config.retryable_exceptions)
    
    def execute(self, func: Callable, *args, **kwargs) -> Any:
        """Execute function with retry logic."""
        last_exception = None
        
        for attempt in range(self.config.max_retries + 1):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                last_exception = e
                
                # Don't retry if not retryable
                if not self.is_retryable(e):
                    raise e
                
                # Don't retry on last attempt
                if attempt == self.config.max_retries:
                    break
                
                # Calculate and apply delay
                delay = self.calculate_delay(attempt)
                print(f"[Retry] Attempt {attempt + 1} failed: {e}. Retrying in {delay:.1f}s...")
                time.sleep(delay)
        
        # All retries exhausted
        raise last_exception


class ResilientExecutor:
    """
    Combines retry logic with circuit breaker for resilient execution.
    """
    
    def __init__(self, name: str):
        self.name = name
        self.retry_handler = RetryHandler()
        self.circuit_breaker = CircuitBreaker(name)
        self.execution_log = []
    
    def execute(self, func: Callable, *args, **kwargs) -> Any:
        """Execute with retry and circuit breaker protection."""
        start_time = time.time()
        
        try:
            # Use circuit breaker
            result = self.circuit_breaker.call(
                self.retry_handler.execute,
                func, *args, **kwargs
            )
            
            # Log success
            self._log_execution(
                status="success",
                duration=time.time() - start_time
            )
            
            return result
            
        except CircuitBreakerOpenError:
            self._log_execution(
                status="circuit_open",
                duration=time.time() - start_time
            )
            raise
            
        except Exception as e:
            self._log_execution(
                status="failed",
                duration=time.time() - start_time,
                error=str(e)
            )
            raise
    
    def _log_execution(self, status: str, duration: float, error: str = None):
        """Log execution attempt."""
        log_entry = {
            "timestamp": datetime.now().isoformat(),
            "executor": self.name,
            "status": status,
            "duration": duration,
            "circuit_state": self.circuit_breaker.state.value
        }
        if error:
            log_entry["error"] = error
        
        self.execution_log.append(log_entry)


def resilient(name: str, max_retries: int = 3, circuit_threshold: int = 5):
    """
    Decorator to make a function resilient with retry and circuit breaker.
    
    Usage:
        @resilient(name="web_search", max_retries=3)
        def search(query: str):
            # Function that might fail
            pass
    """
    executor = ResilientExecutor(name)
    executor.retry_handler.config.max_retries = max_retries
    executor.circuit_breaker.config.failure_threshold = circuit_threshold
    
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            return executor.execute(func, *args, **kwargs)
        
        # Attach executor for monitoring
        wrapper._executor = executor
        return wrapper
    
    return decorator


def test_error_handling():
    """Test error handling system."""
    print("=" * 60)
    print("Error Handling System Test")
    print("=" * 60)
    
    # Test 1: Retry with eventual success
    print("\n1. Testing retry with eventual success:")
    attempt_count = 0
    
    @resilient(name="test_retry", max_retries=3)
    def flaky_function():
        nonlocal attempt_count
        attempt_count += 1
        if attempt_count < 3:
            raise ConnectionError(f"Attempt {attempt_count} failed")
        return f"Success on attempt {attempt_count}"
    
    try:
        result = flaky_function()
        print(f"   Result: {result}")
    except Exception as e:
        print(f"   Failed: {e}")
    
    # Test 2: Circuit breaker
    print("\n2. Testing circuit breaker:")
    
    @resilient(name="test_circuit", max_retries=0, circuit_threshold=2)
    def always_fails():
        raise ConnectionError("Simulated failure")
    
    for i in range(4):
        try:
            always_fails()
        except CircuitBreakerOpenError:
            print(f"   Call {i+1}: Circuit OPEN (blocked)")
        except ConnectionError:
            print(f"   Call {i+1}: Connection error")
    
    # Test 3: Exponential backoff calculation
    print("\n3. Testing exponential backoff:")
    retry = RetryConfig(initial_delay=1.0, max_delay=30.0)
    handler = RetryHandler(retry)
    
    for i in range(5):
        delay = handler.calculate_delay(i)
        print(f"   Attempt {i+1}: delay = {delay:.2f}s")


if __name__ == "__main__":
    test_error_handling()
