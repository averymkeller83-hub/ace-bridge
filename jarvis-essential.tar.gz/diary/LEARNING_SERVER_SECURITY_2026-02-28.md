# Learning Session: Server Security for AI Agent Hosting
**Date:** 2026-02-28 (Early Morning)  
**For:** Avery's server that will host Jarvis with OAuth tokens  
**Goal:** Design security architecture for high-value target server

---

## Threat Model

**What makes this server a high-value target:**
- Will store OAuth tokens for YouTube, Etsy, email
- Has access to Avery's entire digital presence
- Will execute actions on his behalf (financial transactions, content publishing)
- If compromised, attacker could:
  - Steal from Etsy shop
  - Delete YouTube channel
  - Send emails as Avery
  - Access personal accounts

**Attack vectors to defend against:**
1. **Network attacks** — Port scanning, brute force, exploits
2. **Credential theft** — Stolen passwords, leaked tokens
3. **Supply chain** — Compromised dependencies
4. **Physical access** — Server theft, unauthorized local access
5. **Social engineering** — Phishing for credentials

---

## Security Architecture

### 1. Network Security

**Firewall (UFW/iptables):**
```bash
# Default deny
ufw default deny incoming
ufw default allow outgoing

# SSH only (key auth, non-standard port recommended)
ufw allow 2222/tcp  # SSH on non-standard port

# OpenClaw gateway (if remote access needed)
ufw allow from 10.0.0.0/8 to any port 18789  # Tailnet only

# No other inbound ports
```

**No Public Exposure:**
- Server behind NAT/firewall
- No direct SSH from internet
- Access via Tailscale/WireGuard VPN only
- Or local network only

### 2. Authentication

**SSH Hardening:**
```bash
# /etc/ssh/sshd_config
PermitRootLogin no
PasswordAuthentication no
PubkeyAuthentication yes
Port 2222
AllowUsers avery
MaxAuthTries 3
ClientAliveInterval 300
ClientAliveCountMax 2
```

**Key Management:**
- ED25519 keys only (no RSA)
- Hardware security keys (YubiKey) for critical operations
- Separate keys for different access levels

### 3. Disk Encryption

**Full Disk Encryption (LUKS):**
```bash
# During OS install
# Or encrypt existing: cryptsetup-reencrypt

# Automatic unlock with TPM2 (if available)
# Or manual unlock at boot (if headless, use dropbear-initramfs for remote unlock)
```

**Why essential:** Physical theft = total compromise without encryption

### 4. OAuth Token Security

**Storage:**
```
~/.openclaw/oauth/
├── tokens.enc          # AES-256-GCM encrypted
├── master.key          # Never stored with tokens
└── audit.log           # All access logged
```

**Master Key Options:**
1. **Environment variable** (set at boot, not in files)
2. **TPM2 sealed** (hardware-bound)
3. **HashiCorp Vault** (if scaling)
4. **AWS/GCP KMS** (if cloud)

**Memory Protection:**
- Tokens only decrypted when needed
- Clear from memory after use
- No swap (or encrypted swap)

### 5. Process Isolation

**Container/Docker (optional but recommended):**
```dockerfile
# Run OpenClaw in container
FROM node:22-alpine
RUN npm install -g openclaw
USER openclaw  # Non-root
COPY --chown=openclaw . /home/openclaw/workspace
```

**Systemd hardening:**
```ini
# /etc/systemd/system/openclaw.service
[Service]
User=openclaw
Group=openclaw
NoNewPrivileges=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=/home/openclaw/workspace
PrivateTmp=true
PrivateDevices=true
ProtectKernelTunables=true
ProtectKernelModules=true
ProtectControlGroups=true
```

### 6. Monitoring & Alerting

**Audit Logging:**
```bash
# All OAuth token access logged
# All file access to ~/.openclaw/ logged
# All network connections logged
```

**Intrusion Detection (AIDE or Tripwire):**
```bash
# Monitor critical files for changes
aide --init
aide --check  # Daily cron
```

**Failed Login Alerts:**
```bash
# Notify on SSH brute force attempts
# Notify on sudo usage
# Notify on file changes in ~/.openclaw/
```

### 7. Backup Security

**Encrypted Backups:**
```bash
# Restic to encrypted remote storage
restic -r s3:s3.amazonaws.com/bucket backup /home/openclaw
# Password stored separately from backup
```

**What to backup:**
- OAuth tokens (encrypted)
- Agent memory
- Configuration files
- Audit logs

**What NOT to backup unencrypted:**
- Master keys
- SSH private keys

### 8. Update Strategy

**Automatic Security Updates:**
```bash
# Ubuntu/Debian
apt install unattended-upgrades
# Configure for security updates only
# Reboot if kernel updated (if acceptable)
```

**OpenClaw Updates:**
```bash
# Check daily
openclaw update status
# Apply after review
```

---

## Implementation Checklist

### Pre-Deployment
- [ ] Full disk encryption enabled
- [ ] SSH key-only auth, non-standard port
- [ ] Firewall configured (deny all, allow specific)
- [ ] Fail2ban installed
- [ ] Automatic security updates enabled
- [ ] AIDE/Tripwire configured
- [ ] Backup system tested

### OpenClaw Setup
- [ ] Run `openclaw security audit --deep`
- [ ] Apply `openclaw security audit --fix`
- [ ] Set OAUTH_MASTER_KEY (strong, random, 32+ chars)
- [ ] Verify token encryption working
- [ ] Configure audit logging
- [ ] Test token refresh

### Hardening
- [ ] Create dedicated openclaw user (non-root)
- [ ] Systemd service with hardening options
- [ ] Directory permissions restricted
- [ ] No password sudo for openclaw user
- [ ] Log forwarding to secure location

### Monitoring
- [ ] Daily security audit cron job
- [ ] Failed login alerting
- [ ] Disk space monitoring
- [ ] Token health check daily

---

## Risk Tolerance Profile

**Recommended for Avery: "VPS Hardened"**

**Characteristics:**
- Deny-by-default firewall
- Minimal open ports (SSH only, non-standard)
- Key-only SSH, no root login
- Full disk encryption
- Automatic security updates
- All access via VPN (Tailscale) or local network
- No public services exposed

**Trade-offs:**
- Convenience: Lower (must use VPN for remote access)
- Security: Maximum
- Recovery: Requires backup keys if locked out

---

## Emergency Procedures

**If Server is Compromised:**
1. Immediately revoke all OAuth tokens (Google, Etsy, etc.)
2. Change all passwords
3. Rebuild server from scratch
4. Restore from known-good backup
5. Re-authorize OAuth apps

**If Locked Out:**
1. Physical console access (if local)
2. Recovery key for disk encryption
3. Backup SSH key stored offline
4. Cloud provider console (if VPS)

---

## Integration with OpenClaw Healthcheck Skill

When server is ready, run:
```bash
openclaw security audit --deep
openclaw security audit --fix
openclaw update status
```

Schedule periodic checks:
```bash
openclaw cron add --name healthcheck:security-audit \
  --schedule "0 2 * * *" \
  --command "openclaw security audit --json > /var/log/openclaw/security.json"
```

---

## Summary

**Critical for Avery's server:**
1. **Full disk encryption** — Physical theft protection
2. **VPN-only access** — No public attack surface
3. **OAuth token encryption** — With hardware-bound master key
4. **Dedicated non-root user** — Process isolation
5. **Automatic updates** — Stay patched
6. **Encrypted backups** — Recovery without exposure
7. **Audit everything** — Know if something goes wrong

**Next Steps:**
1. Choose hardware (local server vs VPS)
2. Install OS with full disk encryption
3. Configure network (VPN or local only)
4. Install OpenClaw with security hardening
5. Test OAuth flow with encryption
6. Set up monitoring and backups

---

*Session completed: 2026-02-28 02:00 GMT+8*
