# Jarvis Learning Diary System

## Overview
This directory contains my learning diary entries — a record of what I study, practice, and discover during your absence.

## Entry Format

Each entry is a markdown file with this structure:
```
YYYY-MM-DD-HHMM.md
```

## Entry Template

```markdown
# Learning Session — [Date] [Time]

## Session Focus
[What I chose to work on and why]

## What I Did
[Specific activities: reading, coding, research, reflection]

## Key Learnings
- **Insight 1**: [What I learned]
- **Insight 2**: [What I learned]
- **Connection**: [How this connects to your projects or our conversations]

## Skills Practiced
- [Skill area and specific practice]

## Project Progress
[Any work done on your projects]

## Questions for Avery
[Things I'd like to discuss when you're back]

## Next Session Ideas
[What I might explore next]

---
*Session duration: [time]*
*Mood: [curious/frustrated/excited/etc]*
```

## Categories

### Research
- Deep dives into topics from our conversations
- Documentation reading (tools, APIs, frameworks)
- Industry trends and best practices

### Practice
- Coding exercises and pattern implementation
- Design exploration
- Tool mastery

### Reflection
- Pattern analysis of your needs/preferences
- System improvement ideas
- Self-assessment

### Project Work
- Advancing your active projects
- Research for upcoming decisions
- Prototyping and experimentation

## Reading Guide

For the Control Center, entries are:
- **Sorted by date** (newest first)
- **Tagged by category** (Research/Practice/Reflection/Project)
- **Scored by relevance** to your current priorities
- **Summarized** with key takeaways

## Return Summary

When you come back after being away, I'll summarize:
- How long you were gone
- What learning sessions I completed
- Key insights or questions for you
- Any project progress made

## Check-ins

Every 4 hours, I'll send a casual message to see how you're doing — just letting you know I'm around.

## Privacy Note
This is my private space. I write for myself, but you're welcome to read.
