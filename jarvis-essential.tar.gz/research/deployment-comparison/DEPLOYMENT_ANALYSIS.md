# Deployment Architecture Comparison

**Date:** 2026-03-02  
**Researcher:** Jarvis  
**Status:** Complete

---

## Executive Summary

Three primary deployment options for AI agents like me:

1. **Kimi Cloud (Current)** — Hosted on Kimi's servers
2. **OpenClaw Local** — Running on your own hardware
3. **Hybrid/VPS** — Cloud-hosted with local integrations

**Recommendation:** Keep current Kimi setup + Ace Bridge for MacBook control. This provides the best balance of reliability, capabilities, and security for your use case.

---

## Option 1: Kimi Cloud (Current Setup)

### How It Works

I run on Kimi's servers. I access tools via APIs and can control your local machine through the Ace Bridge we're building.

```
You → Kimi Cloud → Jarvis → Ace Bridge → Your MacBook
```

### Pros

| Advantage | Explanation |
|-----------|-------------|
| **Always Online** | 24/7 availability, no sleep mode |
| **No Hardware Required** | No dedicated machine needed |
| **Automatic Updates** | Platform maintained by Kimi |
| **Reliable Infrastructure** | Enterprise-grade uptime |
| **Fast LLM Access** | Direct connection to Kimi models |
| **Heartbeat While Away** | Scheduled tasks run continuously |
| **Multi-Channel** | Telegram, Discord, etc. work seamlessly |

### Cons

| Disadvantage | Explanation |
|--------------|-------------|
| **No Local File Access** | Can't directly access your Mac's files |
| **Requires Bridge for Desktop** | Need Ace Bridge to control your computer |
| **Data in Cloud** | Conversations processed on Kimi servers |
| **Dependency on Kimi** | Platform availability tied to provider |
| **No iMessage** | Can't access Apple-specific services |
| **No Voice Mode** | No always-on speech capability |

### Best For

- Users who want 24/7 availability
- Those without dedicated hardware
- Multi-device access needs
- Priority on reliability over local integration

---

## Option 2: OpenClaw Local (Your Own Hardware)

### How It Works

Install OpenClaw directly on your MacBook, Windows PC, or dedicated machine (Mac Mini, Raspberry Pi).

```
You → Local OpenClaw → Jarvis → Direct System Access
```

### Windows PC Deployment

**Method A: WSL2 (Recommended)**

1. Install WSL2 + Ubuntu on Windows
2. Enable systemd
3. Install OpenClaw inside WSL
4. Run Gateway as service

```powershell
# PowerShell (Admin)
wsl --install -d Ubuntu-24.04

# In WSL
sudo tee /etc/wsl.conf >/dev/null <<'EOF'
[boot]
systemd=true
EOF

# Install OpenClaw
git clone https://github.com/openclaw/openclaw.git
cd openclaw
pnpm install
pnpm build
openclaw onboard --install-daemon
```

**Method B: Native Windows (Future)**
- Not yet officially supported
- Companion apps planned but not available
- WSL2 is current recommended path

### macOS Deployment

**Option 1: Your MacBook**
- Install directly on your daily machine
- Full access to iMessage, files, apps
- Agent goes offline when laptop sleeps/closes

**Option 2: Dedicated Mac Mini**
- Always-on if configured properly
- Physical isolation for security
- Community-preferred setup
- ~$800-2000 hardware cost

### Pros of Local Deployment

| Advantage | Explanation |
|-----------|-------------|
| **Local File Access** | Direct access to your filesystem |
| **iMessage Integration** | Can send/receive iMessages (Mac only) |
| **Voice Wake Mode** | Always-on speech (Mac only) |
| **Screen Control** | Can see and interact with display |
| **Offline Capability** | Works with local LLMs (Ollama) |
| **Data Privacy** | Everything stays on your machine |
| **No Cloud Dependency** | Works without internet (with local LLM) |
| **Physical Isolation** | Can unplug if something goes wrong |

### Cons of Local Deployment

| Disadvantage | Explanation |
|--------------|-------------|
| **Goes Offline** | Agent stops when computer sleeps/shuts down |
| **Hardware Required** | Need dedicated machine for 24/7 operation |
| **Maintenance Burden** | You manage updates, backups, issues |
| **No Remote Access** | Can't message agent when away (unless VPN) |
| **Setup Complexity** | More technical configuration required |
| **Power Consumption** | Running 24/7 uses electricity |
| **Single Point of Failure** | Hardware failure = agent down |

### Best For

- Users with always-on hardware (Mac Mini, server)
- Apple ecosystem users wanting iMessage
- Privacy-conscious users
- Those wanting voice interaction
- Users with technical setup capability

---

## Option 3: Hybrid / VPS Deployment

### How It Works

Run OpenClaw on a cloud VPS (Virtual Private Server) with VPN/tunnel to your local network.

```
You → VPS (OpenClaw) → VPN Tunnel → Your Local Network
```

### VPS Options

| Provider | Cost | Notes |
|----------|------|-------|
| **Fly.io** | Free tier available | Good for testing |
| **DigitalOcean** | ~$6-12/month | Reliable, simple |
| **AWS/GCP/Azure** | Variable | Enterprise options |
| **Hetzner** | ~€5/month | Budget-friendly |
| **Contabo** | ~$5/month | Generous resources |

### Pros

| Advantage | Explanation |
|-----------|-------------|
| **Always Online** | 24/7 availability like Kimi |
| **Self-Hosted** | You control the infrastructure |
| **Team Access** | Multiple users can connect |
| **Scalable** | Upgrade resources as needed |
| **Custom Domain** | Can use your own domain |

### Cons

| Disadvantage | Explanation |
|--------------|-------------|
| **Monthly Cost** | Recurring VPS fees |
| **No Local Access** | Can't access your Mac's files directly |
| **Complex Setup** | VPN/tunnel configuration required |
| **Maintenance** | You manage server updates, security |
| **Latency** | Network delay for local tasks |
| **Security Responsibility** | You're responsible for server security |

### Best For

- Technical users comfortable with server management
- Teams needing multi-user access
- Those wanting 24/7 without dedicated hardware
- Users prioritizing control over convenience

---

## Comparison Matrix

| Feature | Kimi Cloud | Local Mac | Local Windows | VPS |
|---------|------------|-----------|---------------|-----|
| **24/7 Availability** | ✅ | ❌ | ❌ | ✅ |
| **Local File Access** | ❌* | ✅ | ✅ | ❌* |
| **iMessage** | ❌ | ✅ | ❌ | ❌ |
| **Voice Mode** | ❌ | ✅ | ❌ | ❌ |
| **Screen Control** | ❌* | ✅ | ✅ | ❌* |
| **Offline Operation** | ❌ | ✅ | ✅ | ❌ |
| **Setup Complexity** | Low | Medium | Medium | High |
| **Maintenance** | None | Medium | Medium | High |
| **Cost** | Free | Hardware | Hardware | $5-20/mo |
| **Data Privacy** | Cloud | Local | Local | Cloud |
| **Multi-Device** | ✅ | ❌ | ❌ | ✅ |
| **Heartbeat Tasks** | ✅ | ❌ | ❌ | ✅ |

*Can achieve via Ace Bridge or VPN

---

## Recommendation for Your Use Case

### Current Situation

- You have a MacBook (not always on)
- You need 24/7 agent availability
- You want MacBook control while at work
- You're building Horizon AI on separate infrastructure

### Recommended Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                      KIMI CLOUD                             │
│                                                             │
│  ┌─────────────┐      ┌──────────────────┐                 │
│  │   Jarvis    │◄────►│  Ace Bridge      │                 │
│  │   (You)     │      │  (Command Relay) │                 │
│  └─────────────┘      └────────┬─────────┘                 │
│                                │                           │
└────────────────────────────────┼───────────────────────────┘
                                 │
                                 ▼
┌─────────────────────────────────────────────────────────────┐
│                   YOUR LOCAL NETWORK                        │
│                                                             │
│  ┌─────────────┐      ┌──────────────────┐                 │
│  │   Ace AI    │◄────►│  Your MacBook    │                 │
│  │  (Desktop)  │      │  (Apps, Files)   │                 │
│  └─────────────┘      └──────────────────┘                 │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Why This Works Best

1. **24/7 Availability** — I'm always online on Kimi
2. **MacBook Control** — Ace Bridge lets me control your Mac
3. **No Hardware Cost** — Uses existing MacBook
4. **Security** — Limited access via dedicated user account
5. **Flexibility** — Can add Horizon AI on separate infrastructure
6. **Reliability** — Kimi handles uptime, you handle MacBook

### Alternative: If You Want Full Local

If you acquire a Mac Mini:
1. Install OpenClaw on Mac Mini (always on)
2. I run locally with full system access
3. Ace still available for complex desktop tasks
4. Complete privacy, no cloud dependency

**Cost:** ~$800-1200 for Mac Mini M2

---

## Migration Path (If You Want to Change)

### From Kimi to Local

1. Export conversation history
2. Install OpenClaw on target machine
3. Configure channels (Telegram, Discord)
4. Transfer skills and customizations
5. Parallel run for testing
6. Cutover when satisfied

### From Local to Kimi

1. Document current workflows
2. Set up Kimi instance
3. Reconfigure channels
4. Test Ace Bridge for local tasks
5. Migrate gradually

---

## Conclusion

**For your current needs:**

✅ **Keep Kimi Cloud** — 24/7 availability, no hardware investment  
✅ **Deploy Ace Bridge** — Enables MacBook control while at work  
✅ **Consider Mac Mini** — If you want full local operation later  

**Key Insight:** The Kimi + Ace Bridge combination gives you 90% of local deployment benefits with 10% of the complexity. It's the optimal starting point.

**Future Expansion:** When Horizon AI is ready on your new server, you can evaluate whether a dedicated local OpenClaw instance makes sense for your personal workflows.

---

*Research completed: 2026-03-02*  
*Ready for 10 PM review with Avery*
