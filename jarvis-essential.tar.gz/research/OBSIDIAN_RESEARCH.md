# Obsidian — Research Report

**Date:** 2026-03-02  
**Researcher:** Jarvis  
**Status:** Complete

---

## What Is Obsidian?

**Obsidian** is a powerful **knowledge management** and **note-taking** application built around plain-text Markdown files. Launched in 2020, it has become the go-to tool for Personal Knowledge Management (PKM) enthusiasts, researchers, writers, and anyone who wants to build a "second brain."

**Core Philosophy:** Your notes are stored locally as plain text files — you own your data completely.

---

## Key Features

### 1. Markdown-Based

- **Plain text files** — No proprietary format lock-in
- **Standard Markdown** — Works with any text editor
- **Future-proof** — Your notes will always be readable
- **Git-friendly** — Version control your knowledge base

### 2. Bidirectional Linking

**The Core Innovation:**
- Link notes with `[[Note Name]]` syntax
- Automatically creates **backlinks** — see which notes link to current note
- Build a **web of knowledge** rather than isolated documents
- Discover connections you didn't know existed

**Example:**
```markdown
# Artificial Intelligence

AI is transforming [[Healthcare]] and [[Education]].
See also: [[Machine Learning]], [[Neural Networks]].
```

### 3. Graph View

**Visual Knowledge Map:**
- See all your notes as nodes in a graph
- Lines show connections between notes
- Identify clusters of related ideas
- Discover orphaned notes (no connections)
- Navigate visually through your knowledge base

**Use Cases:**
- Research topic exploration
- Finding patterns in your thinking
- Identifying knowledge gaps
- Creative brainstorming

### 4. Local-First Storage

**Your Data, Your Control:**
- All files stored locally on your device
- No cloud dependency (optional sync available)
- Works offline completely
- No vendor lock-in
- Full privacy — your notes never leave your machine

**Storage Options:**
- Local folder (default)
- iCloud/Dropbox/Google Drive (sync)
- Git repository (version control)
- Obsidian Sync (paid official service)

### 5. Extensive Plugin Ecosystem

**1,000+ Community Plugins:**
- AI integration plugins
- Task management
- Calendar and daily notes
- Data visualization
- Publishing tools
- Automation workflows

**Popular Plugin Categories:**
| Category | Examples |
|----------|----------|
| **AI Tools** | AI text generation, chat with notes |
| **Task Management** | Todo lists, Kanban boards, projects |
| **Calendar** | Daily notes, habit tracking, planning |
| **Writing** | Distraction-free mode, word count, templates |
| **Data** | Tables, charts, databases |
| **Publishing** | Export to web, PDF, ePub |

### 6. Canvas (Visual Workspace)

**Infinite Canvas:**
- Arrange notes, images, and ideas visually
- Create mood boards, storyboards, mind maps
- Connect ideas with arrows and relationships
- Present and share visual thinking

### 7. Obsidian Publish

**Turn Notes into Websites:**
- Publish your vault as a public wiki/knowledge base
- Custom domains
- Password protection
- SEO optimized
- Mobile-friendly
- Instant updates from Obsidian app

---

## Use Cases

### For Research
- Literature reviews with linked citations
- Research journals with topic connections
- Zettelkasten method implementation
- Cross-reference related studies

### For Writing
- Long-form writing with linked chapters
- Character/world building for fiction
- Blog post idea management
- Content calendar planning

### For Learning
- Study notes with concept linking
- Language learning vocabulary
- Course material organization
- Skill development tracking

### For Business
- Project documentation
- Meeting notes with action items
- SOP (Standard Operating Procedures)
- Client knowledge bases

### For Personal
- Daily journaling
- Goal tracking
- Book notes and reviews
- Recipe collection

---

## Comparison to Other Tools

| Feature | Obsidian | Notion | Evernote | Roam Research |
|---------|----------|--------|----------|---------------|
| **Storage** | Local | Cloud | Cloud | Cloud |
| **Price** | Free (personal) | Freemium | Freemium | Expensive |
| **Markdown** | Native | Export only | Limited | Native |
| **Linking** | Bidirectional | Limited | None | Bidirectional |
| **Graph View** | ✅ | ❌ | ❌ | ✅ |
| **Offline** | Full | Limited | Limited | Limited |
| **Plugins** | 1,000+ | Limited | Limited | Few |
| **Privacy** | Maximum | Platform | Platform | Platform |

---

## Integration with Your Setup

### For Jarvis (You)

**Knowledge Management:**
- Store all research in Obsidian
- Link related concepts across projects
- Build a personal wiki of everything I learn
- Graph view shows connections between topics

**Workflow Integration:**
```
Research Topic → Write Notes → Link Related Ideas → 
Build Knowledge Graph → Publish Insights → Share with You
```

**AI Integration Plugins:**
- Generate content from notes
- Chat with your knowledge base
- Summarize linked notes
- Find connections automatically

### For Horizon Electronics

**Business Knowledge Base:**
- SOP documentation
- Customer interaction logs
- Product/service catalog
- Team knowledge sharing

**Publishing:**
- Customer-facing documentation
- FAQ/knowledge base website
- Training materials

### For Self-Funding AI Project

**Content Creation:**
- Research notes organized by topic
- Content calendar with linked ideas
- Published articles as public wiki
- Analytics on what content performs

---

## Automation Possibilities

### Obsidian CLI (Command Line Interface)

**Upcoming Feature:**
- Control Obsidian from terminal
- Script automation
- Integration with external tools
- Batch operations

**Potential Uses:**
```bash
# Create daily note
obsidian daily-note

# Search vault
obsidian search "AI agents"

# Export note
obsidian export "Research/Ace Bridge" --format pdf

# Sync with Git
obsidian git-sync
```

### API Access

**Plugin API:**
- Build custom plugins
- Integrate with other tools
- Automate workflows
- Extend functionality

### Integration with Ace Bridge

**Workflow:**
1. Ace creates content on your MacBook
2. Automatically saves to Obsidian vault
3. Links to related notes
4. Updates knowledge graph
5. Publishes if marked for release

---

## Pricing

| Plan | Cost | Features |
|------|------|----------|
| **Personal** | Free | All core features, unlimited devices |
| **Catalyst** | $25 one-time | Early access, supporter badge |
| **Commercial** | $50/year | Commercial use, priority support |
| **Sync** | $8/month | Official sync service |
| **Publish** | $16/month | Website publishing |

**For Your Use:** Personal (free) is sufficient to start.

---

## Getting Started

### Step 1: Download
- https://obsidian.md/
- Available for Windows, Mac, Linux, iOS, Android

### Step 2: Create Vault
- A vault is just a folder on your computer
- Choose location (Documents, Dropbox, etc.)
- Start with one vault, add more later

### Step 3: Write First Note
- Create new note (Ctrl/Cmd + N)
- Write in Markdown
- Link to other notes with `[[ ]]``

### Step 4: Explore Graph View
- Open Graph View (Ctrl/Cmd + G)
- See your notes as connected nodes
- Click to navigate

### Step 5: Install Plugins
- Settings → Community Plugins
- Browse 1,000+ plugins
- Start with: Daily Notes, Templates, Graph Analysis

---

## Recommended Workflow

### Daily Notes
```
2026-03-02.md
├── Morning thoughts
├── Meetings/Calls
├── Research findings
├── Ideas to explore
└── Links to project notes
```

### Project Notes
```
Ace Bridge Project/
├── Overview
├── Research/
│   ├── Ace Capabilities
│   ├── Security Analysis
│   └── Deployment Options
├── Implementation/
│   ├── Setup Guide
│   ├── Testing Results
│   └── Troubleshooting
└── Resources/
    ├── Links
    └── Code Snippets
```

### Knowledge Base
```
Concepts/
├── AI Agents/
│   ├── Autonomous Agents
│   ├── Multi-Agent Systems
│   └── Agent Frameworks
├── Business/
│   ├── Lead Generation
│   ├── Automation
│   └── Passive Income
└── Technology/
    ├── OpenClaw
    ├── Ace AI
    └── Abacus
```

---

## Why Obsidian Fits Your Setup

1. **Local-First** — Works with your privacy/security focus
2. **Markdown** — Future-proof, works with any tool
3. **Linking** — Perfect for connecting research topics
4. **Plugins** — Extensible for AI integration
5. **Publishing** — Turn research into public knowledge base
6. **Free** — No cost to start
7. **Automation-Ready** — CLI coming, API available

---

## Key Takeaways

- Obsidian is a **local-first, Markdown-based** knowledge manager
- **Bidirectional linking** creates a web of connected ideas
- **Graph view** visualizes your knowledge
- **1,000+ plugins** extend functionality
- **Free for personal use**
- **Perfect for research, writing, and building a second brain**
- **Integrates well with automation and AI tools**

---

## Questions

1. Should I set up an Obsidian vault for our research?
2. Would you like me to create a structured knowledge base template?
3. Should we explore Obsidian Publish for sharing research publicly?
4. Any specific plugins you'd like me to research?

---

*Research complete. Obsidian is a powerful tool for knowledge management that aligns well with your research-heavy workflow.*
