# USER.md - About Your Human

- **Name:** Avery
- **What to call them:** Avery
- **Timezone:** GMT+8 (assuming based on timestamps)

## Context
Just getting started. More to learn.
