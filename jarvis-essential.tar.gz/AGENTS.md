# AGENTS.md - Agent Registry

## Authority
See [COMMANDER.md](./COMMANDER.md) — tight control, real-time updates.

## Active Agents

### Agent: workflow-collapse-research
- **Project:** workflow-collapse
- **Status:** terminated
- **Spawned:** 2026-02-18 06:40 GMT+8
- **Terminated:** 2026-02-22 01:30 GMT+8
- **Approved by:** Avery
- **Task:** Research content pipeline for AI job displacement YouTube Shorts
- **Session:** agent:main:subagent:4a2792c5-5163-487a-b20d-393e992417ff
- **Outcome:** No response to status check; session unresponsive. Terminated.

### Agent: memory-agent
- **Project:** memory-agent skill
- **Status:** complete
- **Spawned:** 2026-02-18 05:59 GMT+8
- **Completed:** 2026-02-18 (status updated 2026-02-22)
- **Approved by:** Avery
- **Task:** Create memory/retrieval skill for conversation history indexing and search
- **Session:** agent:main:subagent:dda70a92-3f3f-4336-839b-199b7d0462a3
- **Deliverables:** embeddings.py, memory_enhanced.py, SKILL.md, indexed 6 memories

### Agent: cli-agent
- **Project:** jarvis-cli
- **Status:** complete
- **Spawned:** 2026-02-18 05:47 GMT+8
- **Approved by:** Avery
- **Task:** Create CLI tool for managing projects and agents
- **Session:** agent:main:subagent:f3913b95-0879-4d72-9a27-c7dd65fc6446

### Agent: docs-agent
- **Project:** jarvis-docs
- **Status:** complete
- **Spawned:** 2026-02-18 05:44 GMT+8
- **Approved by:** Avery
- **Task:** Create comprehensive documentation (SETUP, USAGE, AGENTS, TROUBLESHOOTING, REFERENCE)
- **Session:** agent:main:subagent:38bf3604-77fa-4361-a42f-409ea4c1e3b8

### Agent: git-sync-agent
- **Project:** git-auto-sync skill
- **Status:** complete
- **Spawned:** 2026-02-18 05:35 GMT+8
- **Approved by:** Avery
- **Task:** Create automated git backup skill with sync.py, install.sh, and SKILL.md
- **Session:** agent:main:subagent:50f253a7-d314-4347-970f-81928a9f3022

## Agent Template

### Agent: [name]
- **Project:** [project folder]
- **Status:** [idle | working | blocked | complete]
- **Spawned:** [timestamp]
- **Approved by:** Avery
- **Task:** [brief description]

## Communication
- Agents report to their project's `agents/[name]/LOG.md`
- Commander (Jarvis) monitors in real-time
- Blocked agents → instant escalation to Avery
- All spawns require explicit approval
